# 📚 Guia Completo de Instalação — AssistiView SDK Landing Page

## Índice

1. [Pré-requisitos](#pr%C3%A9-requisitos)

1. [Instalação do Projeto](#instala%C3%A7%C3%A3o-do-projeto)

1. [Explicação das Dependências](#explica%C3%A7%C3%A3o-das-depend%C3%AAncias)

1. [Estrutura do Projeto](#estrutura-do-projeto)

1. [Comandos Disponíveis](#comandos-dispon%C3%ADveis)

1. [Troubleshooting](#troubleshooting)

---

## Pré-requisitos

Antes de começar, certifique-se de que você tem instalado:

### 1. **Node.js** (v18+)

```bash
# Verificar se Node.js está instalado
node --version
# Esperado: v18.0.0 ou superior

# Se não tiver, baixe em: https://nodejs.org/
```

### 2. **pnpm** (gerenciador de pacotes )

```bash
# Verificar se pnpm está instalado
pnpm --version
# Esperado: 10.4.1 ou superior

# Se não tiver, instale globalmente:
npm install -g pnpm

# Ou use o npm (que vem com Node.js):
npm install -g pnpm@10.4.1
```

### 3. **Git** (opcional, mas recomendado)

```bash
git --version
# Esperado: git version 2.x.x ou superior
```

---

## Instalação do Projeto

### Passo 1: Clonar ou Entrar no Diretório do Projeto

Se você tem o projeto em um repositório Git:

```bash
git clone https://github.com/seu-usuario/assistiview-landing.git
cd assistiview-landing
```

Ou, se já tem o diretório local:

```bash
cd /home/ubuntu/assistiview-landing
```

### Passo 2: Instalar Dependências

Use o **pnpm** para instalar todas as dependências (recomendado ):

```bash
pnpm install
```

**Alternativa com npm:**

```bash
npm install
```

**Alternativa com yarn:**

```bash
yarn install
```

> **Por que pnpm?** O pnpm é mais rápido, usa menos espaço em disco e tem melhor resolução de dependências. Veja a seção "Explicação das Dependências" abaixo.

### Passo 3: Verificar Instalação

Após a instalação, verifique se tudo está correto:

```bash
# Verificar se o TypeScript compila sem erros
pnpm check

# Esperado: Sem erros de compilação
```

### Passo 4: Iniciar o Servidor de Desenvolvimento

```bash
pnpm dev
```

Você verá algo como:

```
➜  Local:   http://localhost:3000/
➜  Network: http://169.254.0.21:3000/
```

Abra [http://localhost:3000/](http://localhost:3000/) no navegador. A landing page deve aparecer! 🎉

---

## Explicação das Dependências

O projeto usa **65 dependências** no total. Aqui estão as principais agrupadas por categoria:

### 🎨 **UI & Styling** (Tailwind + Radix UI )

| Pacote | Versão | Propósito |
| --- | --- | --- |
| `tailwindcss` | 4.1.14 | Framework CSS utilitário |
| `@tailwindcss/vite` | 4.1.3 | Plugin Vite para Tailwind |
| `@tailwindcss/typography` | 0.5.15 | Plugin para estilizar texto/markdown |
| `tailwindcss-animate` | 1.0.7 | Animações prontas para Tailwind |
| `tw-animate-css` | 1.4.0 | Mais animações CSS |
| `tailwind-merge` | 3.3.1 | Merge inteligente de classes Tailwind |
| `@radix-ui/*` | v1.x | 22 componentes de UI acessíveis (Button, Dialog, Select, etc.) |

**Por que Tailwind + Radix UI?**

- **Tailwind**: Classes utilitárias para estilização rápida e consistente

- **Radix UI**: Componentes acessíveis (WCAG 2.1 AA) sem estilo padrão — você controla tudo com Tailwind

### ⚛️ **React & Core**

| Pacote | Versão | Propósito |
| --- | --- | --- |
| `react` | 19.2.1 | Biblioteca React (última versão) |
| `react-dom` | 19.2.1 | Renderização React no DOM |
| `wouter` | 3.3.5 | Roteamento client-side leve (alternativa ao React Router) |

**Por que wouter?**

- Muito leve (~3KB gzipped)

- Perfeito para landing pages e SPAs pequenas

- Suporta lazy loading de rotas

### 🎬 **Animações & Motion**

| Pacote | Versão | Propósito |
| --- | --- | --- |
| `framer-motion` | 12.23.22 | Animações fluidas e gestos |

**Usado em:** Scroll reveal, hover effects, transições suaves

### 📝 **Formulários & Validação**

| Pacote | Versão | Propósito |
| --- | --- | --- |
| `react-hook-form` | 7.64.0 | Gerenciamento de formulários |
| `@hookform/resolvers` | 5.2.2 | Validação com Zod/Yup |
| `zod` | 4.1.12 | Validação de schemas TypeScript |

### 🎯 **Ícones & Utilitários**

| Pacote | Versão | Propósito |
| --- | --- | --- |
| `lucide-react` | 0.453.0 | Ícones SVG (usado no Navbar, Features, etc.) |
| `clsx` | 2.1.1 | Merge condicional de classes CSS |
| `class-variance-authority` | 0.7.1 | Criação de componentes com variantes |
| `nanoid` | 5.1.5 | Gerador de IDs únicas |
| `axios` | 1.12.0 | Cliente HTTP (para requisições futuras) |

### 🎨 **Temas & Markdown**

| Pacote | Versão | Propósito |
| --- | --- | --- |
| `next-themes` | 0.4.6 | Gerenciamento de temas (dark/light) |
| `streamdown` | 1.4.0 | Renderização de Markdown em React |
| `sonner` | 2.0.7 | Toast notifications (notificações) |

### 🔧 **Dev Dependencies** (Ferramentas de Desenvolvimento)

| Pacote | Versão | Propósito |
| --- | --- | --- |
| `vite` | 7.1.7 | Build tool moderno (substitui Webpack) |
| `@vitejs/plugin-react` | 5.0.4 | Plugin React para Vite |
| `typescript` | 5.6.3 | Tipagem estática para JavaScript |
| `prettier` | 3.6.2 | Formatador de código |
| `esbuild` | 0.25.0 | Bundler ultra-rápido |
| `postcss` | 8.4.47 | Processador de CSS |
| `autoprefixer` | 10.4.20 | Adiciona prefixos de navegador (-webkit-, -moz-) |

---

## Estrutura do Projeto

```
assistiview-landing/
├── client/                          # Frontend (React)
│   ├── public/                      # Arquivos estáticos pequenos
│   │   ├── favicon.ico
│   │   ├── robots.txt
│   │   └── manifest.json
│   ├── src/
│   │   ├── components/              # Componentes reutilizáveis
│   │   │   ├── Navbar.tsx           # Navegação fixa com menu mobile
│   │   │   ├── Hero.tsx             # Seção hero com background animado
│   │   │   ├── Features.tsx         # Grid de 6 features
│   │   │   ├── HowItWorks.tsx       # 4 passos com código
│   │   │   ├── InstallSection.tsx   # Tabs de instalação
│   │   │   ├── DocsSection.tsx      # Cards de documentação
│   │   │   ├── Footer.tsx           # Rodapé
│   │   │   └── ErrorBoundary.tsx    # Tratamento de erros
│   │   ├── pages/
│   │   │   ├── Home.tsx             # Página principal (compõe todos os componentes)
│   │   │   └── NotFound.tsx         # Página 404
│   │   ├── contexts/
│   │   │   └── ThemeContext.tsx     # Contexto para tema dark/light
│   │   ├── hooks/
│   │   │   └── (hooks customizados)
│   │   ├── lib/
│   │   │   └── (funções utilitárias)
│   │   ├── App.tsx                  # Componente raiz com rotas
│   │   ├── main.tsx                 # Entry point do React
│   │   └── index.css                # Estilos globais + design system
│   ├── index.html                   # HTML template
│   └── tsconfig.json                # Configuração TypeScript
├── server/                          # Backend (Express) — placeholder
│   └── index.ts
├── shared/                          # Código compartilhado — placeholder
│   └── const.ts
├── package.json                     # Dependências e scripts
├── vite.config.ts                   # Configuração Vite
├── tailwind.config.ts               # Configuração Tailwind
├── postcss.config.js                # Configuração PostCSS
├── tsconfig.json                    # Configuração TypeScript global
├── prettier.config.js               # Configuração Prettier
├── .gitignore                       # Arquivos ignorados pelo Git
└── README.md                        # Documentação do projeto
```

---

## Comandos Disponíveis

### Desenvolvimento

```bash
# Iniciar servidor de desenvolvimento com hot reload
pnpm dev

# Compilar TypeScript sem emitir código (verificar erros)
pnpm check

# Formatar código com Prettier
pnpm format
```

### Produção

```bash
# Build para produção
pnpm build

# Visualizar build localmente
pnpm preview

# Iniciar servidor em modo produção
pnpm start
```

---

## Explicação Linha por Linha — Exemplo: Navbar.tsx

Vou usar o **Napvbar.tsx** como exemplo para ensinar a estrutura de um componente React:

```tsx
/* ============================================================
   Navbar — AssistiView SDK Landing Page
   Design: "Signal & Structure" — sticky, blur backdrop, logo + nav links
   ============================================================ */

import { useState, useEffect } from "react";

// URL da logo hospedada no CDN
const LOGO_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663441144974/Myyhi5NYLkCckQXr947Qbj/logo-assistiview_217f65cf.png";

// Array de links de navegação
const navLinks = [
  { label: "Recursos", href: "#features" },
  { label: "Como funciona", href: "#how-it-works" },
  { label: "Instalação", href: "#install" },
  { label: "Documentação", href: "#docs" },
];

export default function Navbar( ) {
  // Estado: navbar tem fundo quando scrollou?
  const [scrolled, setScrolled] = useState(false);
  
  // Estado: menu mobile está aberto?
  const [menuOpen, setMenuOpen] = useState(false);

  // Hook: detectar scroll
  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Função: scroll suave para seção
  const handleNavClick = (href: string) => {
    setMenuOpen(false);
    const el = document.querySelector(href);
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-[#041723]/90 backdrop-blur-md border-b border-[#1D9BEE]/20 shadow-lg shadow-[#1D9BEE]/5"
          : "bg-transparent"
      }`}
    >
      {/* ... resto do código ... */}
    </header>
  );
}
```

### Explicação Linha por Linha:

**Linha 1-4:** Comentário explicando o propósito do componente

**Linha 6:** Importar `useState` (gerencia estado) e `useEffect` (efeitos colaterais) do React

**Linha 9:** Constante com URL da logo no CDN (não muda durante a execução)

**Linha 12-16:** Array de objetos com os links de navegação. Cada link tem `label` (texto) e `href` (âncora)

**Linha 18:** Exportar o componente como padrão

**Linha 19-20:** `useState(false)` cria um estado chamado `scrolled`. Inicialmente `false` (não scrollou)

**Linha 22-23:** `useState(false)` cria estado `menuOpen` para controlar se menu mobile está aberto

**Linha 25-30:** `useEffect` executa código quando o componente monta. Adiciona listener de scroll que atualiza `scrolled` quando `window.scrollY > 20`

**Linha 31:** Função que fecha menu mobile, encontra elemento com `querySelector` e faz scroll suave com `scrollIntoView({ behavior: "smooth" })`

**Linha 33-41:** JSX do header. Classes Tailwind mudam dinamicamente baseado no estado `scrolled`

---

## Troubleshooting

### ❌ Erro: "pnpm: command not found"

**Solução:**

```bash
npm install -g pnpm
# Ou especifique a versão:
npm install -g pnpm@10.4.1
```

### ❌ Erro: "Cannot find module 'react'"

**Solução:**

```bash
# Reinstale dependências
pnpm install
# Ou limpe cache e reinstale
pnpm install --force
```

### ❌ Erro: "Port 3000 already in use"

**Solução:**

```bash
# Matar processo na porta 3000
# Linux/Mac:
lsof -i :3000
kill -9 <PID>

# Windows:
netstat -ano | findstr :3000
taskkill /PID <PID> /F

# Ou usar porta diferente:
pnpm dev -- --port 3001
```

### ❌ Erro: "TypeScript compilation error"

**Solução:**

```bash
# Verificar erros
pnpm check

# Formatar código
pnpm format

# Reinstalar dependências
pnpm install --force
```

### ❌ Imagens não carregam

**Motivo:** Imagens estão no CDN, não localmente

**Solução:** Verificar se as URLs estão corretas nos componentes:

```bash
# Procurar URLs de imagem
grep -r "d2xsxph8kpxj0f.cloudfront.net" client/src/
```

---

## Próximos Passos

1. ✅ **Instalar dependências** — `pnpm install`

1. ✅ **Iniciar servidor** — `pnpm dev`

1. ✅ **Abrir no navegador** — [http://localhost:3000](http://localhost:3000)

1. 📖 **Estudar componentes** — Comece pelo `Navbar.tsx`

1. 🎨 **Customizar cores** — Edite `client/src/index.css`

1. 📝 **Adicionar conteúdo** — Modifique componentes em `client/src/components/`

---

**Dúvidas?** Revise a seção "Explicação das Dependências" ou pergunte! 🚀

