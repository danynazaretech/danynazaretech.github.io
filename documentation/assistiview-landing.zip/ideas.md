# AssistiView SDK — Ideias de Design para Landing Page

## Contexto
SDK Kotlin para acessibilidade em dispositivos móveis. A logomarca usa azul vibrante (#1D9BEE) com pontos Braille representados na tela de um smartphone. O público é desenvolvedores Android e entusiastas de acessibilidade.

---

<response>
<probability>0.07</probability>
<idea>

## Abordagem 1: "Precision Engineering" — Brutalismo Técnico Acessível

**Design Movement:** Brutalismo digital com influência de documentação técnica (estilo Stripe Docs / Linear)

**Core Principles:**
- Contraste radical: fundo quase-preto (#041723) com azul elétrico (#1D9BEE) como único acento
- Tipografia monospace para código, sans-serif condensada para títulos
- Grid assimétrico com colunas de largura variável (60/40 split)
- Bordas visíveis e estrutura exposta como elemento estético

**Color Philosophy:**
- Fundo: #041723 (azul-noite profundo da paleta av-blue-950)
- Primário: #1D9BEE (azul da logo)
- Acento: #4EB1F1 (av-blue-400) para hover states
- Texto: #ECF7FD (av-blue-50) sobre fundos escuros
- Código: #82C8F5 (av-blue-300) em blocos de sintaxe

**Layout Paradigm:**
- Hero dividido verticalmente: texto à esquerda (60%), mockup de código à direita (40%)
- Seções com bordas top/bottom em azul elétrico
- Navegação horizontal com underline animado

**Signature Elements:**
- Blocos de código Kotlin com syntax highlighting em azul
- Padrão de pontos Braille como textura de fundo sutil
- Linha de "terminal" animada no hero

**Interaction Philosophy:**
- Hover em cards: borda azul aparece com translate-y(-2px)
- Scroll reveal com fade-in lateral
- CTA principal com efeito de "glow" pulsante

**Animation:**
- Entrada do hero: texto desliza da esquerda, código da direita (200ms delay)
- Contador animado nas métricas (0 → valor final em 1.5s)
- Cursor piscante no bloco de terminal

**Typography System:**
- Display: Space Grotesk Bold (títulos)
- Body: Inter Regular (corpo de texto)
- Code: JetBrains Mono (blocos de código)

</idea>
</response>

---

<response>
<probability>0.06</probability>
<idea>

## Abordagem 2: "Inclusive Clarity" — Minimalismo Acessível com Calor Humano

**Design Movement:** Minimalismo escandinavo com toque de design humanista (estilo Figma / Notion)

**Core Principles:**
- Espaço em branco generoso como elemento de respiração
- Hierarquia tipográfica clara sem decoração excessiva
- Azul como única cor de ação, tudo mais em tons neutros quentes
- Componentes com raio de borda grande (16px+) para suavidade

**Color Philosophy:**
- Fundo: #FAFAFA (quase branco com calor)
- Primário: #1D9BEE (azul da logo)
- Superfície: #ECF7FD (av-blue-50) para cards
- Texto principal: #0E1B2A (quase preto azulado)
- Texto secundário: #5A7A8A (cinza-azulado)

**Layout Paradigm:**
- Hero centralizado com ilustração à direita flutuando
- Seções alternando fundo branco e av-blue-50
- Cards em grid 3 colunas com sombra suave

**Signature Elements:**
- Ícones de acessibilidade (bengala, fone, mão) em azul
- Ilustrações flat de pessoas usando smartphones
- Badges de "WCAG 2.1 AA" e "Android Accessibility"

**Interaction Philosophy:**
- Transições suaves 300ms ease-in-out em todos os estados
- Cards com sombra que aumenta no hover
- Botões com ripple effect sutil

**Animation:**
- Fade-in sequencial das seções no scroll (stagger 100ms)
- Ilustração do hero com float animation suave
- Números de métricas contam ao entrar na viewport

**Typography System:**
- Display: Plus Jakarta Sans ExtraBold
- Body: Plus Jakarta Sans Regular
- Code: Fira Code

</idea>
</response>

---

<response>
<probability>0.08</probability>
<idea>

## Abordagem 3: "Signal & Structure" — Editorial Técnico com Profundidade

**Design Movement:** Design editorial moderno com influência de publicações tech (estilo Vercel / Resend)

**Core Principles:**
- Fundo branco puro com seções de destaque em azul profundo
- Tipografia com contraste extremo de peso (900 vs 300)
- Layout em diagonal/clip-path para quebrar a monotonia
- Código como elemento visual central, não secundário

**Color Philosophy:**
- Fundo: #FFFFFF (branco puro)
- Seção hero: gradiente de #082E47 → #0E4D77 (azuis profundos)
- Primário: #1D9BEE (azul da logo)
- Acento claro: #AFDCF9 (av-blue-200) para destaques em fundos escuros
- Texto sobre escuro: #ECF7FD (av-blue-50)

**Layout Paradigm:**
- Hero em fundo escuro com clip-path diagonal na base
- Seções de features com layout alternado (texto-imagem, imagem-texto)
- Footer em azul profundo espelhando o hero

**Signature Elements:**
- Padrão de grade técnica (blueprint) como textura no hero
- Mockup de smartphone 3D com tela do app
- Linha de código Kotlin como "tagline" secundária

**Interaction Philosophy:**
- Parallax sutil no hero (background move 0.3x scroll speed)
- Cards de features com border-left colorido no hover
- Navegação com blur backdrop no scroll

**Animation:**
- Hero: texto aparece com clip-path expanding (wipe effect)
- Features: slide-in alternado (esquerda/direita) no scroll
- Partículas sutis no fundo do hero (pontos Braille animados)

**Typography System:**
- Display: Syne ExtraBold (títulos impactantes)
- Body: DM Sans Regular
- Code: JetBrains Mono

</idea>
</response>

---

## Decisão

**Escolhida: Abordagem 3 — "Signal & Structure"**

Justificativa: Combina o impacto visual de um hero escuro (que remete à seriedade técnica do SDK) com seções claras e legíveis para desenvolvedores. O clip-path diagonal cria movimento sem sacrificar a acessibilidade. A tipografia Syne + DM Sans oferece personalidade sem ser genérica. Os pontos Braille animados no hero são um tributo direto à logomarca e à missão do produto.
