# 🔧 Troubleshooting: "dist" does not exist

## ❌ Erro Completo

```
error when starting preview server:
Error: The directory "dist" does not exist. Did you build your project?
```

## ✅ Solução

O erro acontece porque você tentou rodar `pnpm preview` sem fazer o build primeiro.

**`pnpm preview`** mostra a versão PRODUÇÃO do seu site (após build).
**`pnpm dev`** mostra a versão DESENVOLVIMENTO (ao vivo).

### Passo 1: Fazer o Build

```bash
pnpm build
```

Isso vai criar a pasta `dist/` com os arquivos compilados.

**Esperado:**
```
✓ 1234 modules transformed
dist/index.html                  2.45 kB
dist/assets/index-abc123.js      145.67 kB
dist/assets/index-def456.css     12.34 kB
```

### Passo 2: Visualizar o Build

```bash
pnpm preview
```

Agora vai funcionar! Você verá:

```
➜  Local:   http://localhost:4173/
➜  Network: http://192.168.x.x:4173/
```

---

## 📊 Diferença Entre os Comandos

| Comando | O que faz | Pasta | Porta | Uso |
|---------|----------|-------|-------|-----|
| `pnpm dev` | Servidor de desenvolvimento com hot reload | Não cria `dist/` | 3000 | Desenvolvimento |
| `pnpm build` | Compila para produção | Cria `dist/` | N/A | Antes de deploy |
| `pnpm preview` | Visualiza o build em produção | Usa `dist/` | 4173 | Testar antes de deploy |
| `pnpm start` | Roda servidor Express em produção | Usa `dist/` | 3000 | Produção |

---

## 🚀 Fluxo Correto

### Para Desenvolvimento:

```bash
# 1. Instalar dependências (1x)
pnpm install

# 2. Iniciar servidor de desenvolvimento
pnpm dev

# 3. Abrir no navegador
# http://localhost:3000

# 4. Editar código — muda automaticamente (hot reload)
```

### Para Testar Produção Localmente:

```bash
# 1. Fazer build
pnpm build

# 2. Visualizar
pnpm preview

# 3. Abrir no navegador
# http://localhost:4173
```

### Para Fazer Deploy:

```bash
# 1. Fazer build
pnpm build

# 2. Fazer start
pnpm start

# 3. Servidor roda em produção
# http://localhost:3000
```

---

## 🧹 Limpar e Reconstruir

Se o build ficou corrompido:

```bash
# 1. Remover pasta dist
rm -rf dist

# 2. Remover cache
rm -rf node_modules/.vite

# 3. Reconstruir
pnpm build

# 4. Visualizar
pnpm preview
```

**No Windows (PowerShell):**

```powershell
# 1. Remover pasta dist
Remove-Item -Recurse -Force dist

# 2. Remover cache
Remove-Item -Recurse -Force node_modules\.vite

# 3. Reconstruir
pnpm build

# 4. Visualizar
pnpm preview
```

---

## 📝 Checklist

- [ ] Executei `pnpm install`
- [ ] Executei `pnpm build` (criou pasta `dist/`)
- [ ] Executei `pnpm preview`
- [ ] Abri http://localhost:4173
- [ ] Landing page apareceu

---

## 💡 Dica Pro

Se você quer fazer build + preview em um comando:

```bash
pnpm build && pnpm preview
```

Ou criar um script customizado no `package.json`:

```json
{
  "scripts": {
    "dev": "vite --host",
    "build": "vite build && esbuild server/index.ts --platform=node --packages=external --bundle --format=esm --outdir=dist",
    "preview": "vite preview --host",
    "start": "NODE_ENV=production node dist/index.js",
    "build:preview": "pnpm build && pnpm preview"
  }
}
```

Depois usar:

```bash
pnpm build:preview
```

---

## 🔍 Verificar Estrutura de Pastas

Após `pnpm build`, sua pasta deve ter:

```
assistiview-landing/
├── client/
├── server/
├── dist/                    ← Criada após build
│   ├── index.html
│   ├── assets/
│   │   ├── index-xxx.js
│   │   └── index-xxx.css
│   └── public/
├── node_modules/
├── package.json
└── vite.config.ts
```

---

## ❓ Perguntas Frequentes

### P: Posso deletar a pasta `dist/`?

**R:** Sim! Ela é gerada automaticamente com `pnpm build`.

### P: Por que `pnpm preview` usa porta 4173?

**R:** Vite usa 4173 como padrão para preview. Você pode mudar:

```bash
pnpm preview -- --port 5000
```

### P: `pnpm dev` e `pnpm preview` mostram a mesma coisa?

**R:** Não! 
- `pnpm dev` = versão de desenvolvimento (sem otimizações)
- `pnpm preview` = versão de produção (otimizada, minificada)

### P: Qual usar para desenvolvimento?

**R:** Sempre `pnpm dev`. É mais rápido e tem hot reload.

### P: Qual usar antes de fazer deploy?

**R:** `pnpm build && pnpm preview` para testar a versão final.

---

## 🎯 Resumo

| Erro | Causa | Solução |
|------|-------|---------|
| "dist does not exist" | Falta fazer build | `pnpm build` |
| Mudanças não aparecem | Usando preview em vez de dev | `pnpm dev` |
| Build muito lento | Primeira vez | Normal, próximos são rápidos |
| Porta 4173 já em uso | Outro processo | `pnpm preview -- --port 5000` |

---

**Pronto?** Execute:

```bash
pnpm build && pnpm preview
```

E abra http://localhost:4173 🚀
