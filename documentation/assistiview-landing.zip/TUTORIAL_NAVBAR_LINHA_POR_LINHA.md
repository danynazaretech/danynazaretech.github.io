# 🎯 Tutorial: Navbar.tsx — Linha por Linha

## 📚 O que Vamos Aprender

Vamos desconstruir o componente `Navbar.tsx` e entender:

1. **Imports** — o que cada biblioteca faz
2. **Estado (useState)** — como gerenciar dados que mudam
3. **Efeitos (useEffect)** — como executar código quando o componente monta/atualiza
4. **JSX** — como estruturar a interface
5. **Tailwind CSS** — como estilizar com classes
6. **Responsividade** — como adaptar para mobile/desktop

---

## 📄 Arquivo Completo com Números de Linha

```tsx
001  /* ============================================================
002     Navbar — AssistiView SDK Landing Page
003     Design: "Signal & Structure" — sticky, blur backdrop, logo + nav links
004     ============================================================ */
005
006  import { useState, useEffect } from "react";
007
008  const LOGO_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663441144974/Myyhi5NYLkCckQXr947Qbj/logo-assistiview_217f65cf.png";
009
010  const navLinks = [
011    { label: "Recursos", href: "#features" },
012    { label: "Como funciona", href: "#how-it-works" },
013    { label: "Instalação", href: "#install" },
014    { label: "Documentação", href: "#docs" },
015  ];
016
017  export default function Navbar() {
018    // Estado: navbar tem fundo quando scrollou?
019    const [scrolled, setScrolled] = useState(false);
020    
020    // Estado: menu mobile está aberto?
021    const [menuOpen, setMenuOpen] = useState(false);
022
023    // Hook: detectar scroll
024    useEffect(() => {
025      const handleScroll = () => setScrolled(window.scrollY > 20);
026      window.addEventListener("scroll", handleScroll);
027      return () => window.removeEventListener("scroll", handleScroll);
028    }, []);
029
030    // Função: scroll suave para seção
031    const handleNavClick = (href: string) => {
032      setMenuOpen(false);
033      const el = document.querySelector(href);
034      if (el) el.scrollIntoView({ behavior: "smooth" });
035    };
036
037    return (
038      <header
039        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
040          scrolled
041            ? "bg-[#041723]/90 backdrop-blur-md border-b border-[#1D9BEE]/20 shadow-lg shadow-[#1D9BEE]/5"
042            : "bg-transparent"
043        }`}
044      >
045        <div className="container">
046          <nav className="flex items-center justify-between h-16 md:h-20">
047            {/* Logo */}
047            <a
048              href="#"
049              className="flex items-center gap-2"
050              aria-label="AssistiView SDK — Página inicial"
051            >
052              <img
053                src={LOGO_URL}
053                alt="AssistiView SDK"
054                className="h-8 md:h-10 w-auto"
055              />
056            </a>
057
058            {/* Desktop nav links */}
059            <div className="hidden md:flex items-center gap-8">
060              {navLinks.map((link) => (
061                <button
062                  key={link.href}
063                  onClick={() => handleNavClick(link.href)}
064                  className="text-[#AFDCF9] hover:text-white text-sm font-medium transition-colors duration-200 relative group"
064                >
065                  {link.label}
066                  <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-[#1D9BEE] transition-all duration-300 group-hover:w-full" />
067                </button>
068              ))}
069            </div>
070
071            {/* CTA button */}
072            <div className="hidden md:flex items-center gap-4">
073              <a
074                href="#install"
075                onClick={(e) => { e.preventDefault(); handleNavClick("#install"); }}
076                className="px-5 py-2 bg-[#1D9BEE] hover:bg-[#1883CA] text-white text-sm font-semibold rounded-lg transition-all duration-200 hover:shadow-lg hover:shadow-[#1D9BEE]/30"
077              >
078                Começar agora
079              </a>
080            </div>
081
082            {/* Mobile hamburger */}
083            <button
084              className="md:hidden flex flex-col gap-1.5 p-2"
085              onClick={() => setMenuOpen(!menuOpen)}
086              aria-label={menuOpen ? "Fechar menu" : "Abrir menu"}
087            >
088              <span className={`block w-6 h-0.5 bg-[#AFDCF9] transition-all duration-300 ${menuOpen ? "rotate-45 translate-y-2" : ""}`} />
089              <span className={`block w-6 h-0.5 bg-[#AFDCF9] transition-all duration-300 ${menuOpen ? "opacity-0" : ""}`} />
090              <span className={`block w-6 h-0.5 bg-[#AFDCF9] transition-all duration-300 ${menuOpen ? "-rotate-45 -translate-y-2" : ""}`} />
091            </button>
092          </nav>
093
094          {/* Mobile menu */}
095          {menuOpen && (
096            <div className="md:hidden bg-[#041723]/95 backdrop-blur-md border-t border-[#1D9BEE]/20 py-4 flex flex-col gap-4 px-4">
097              {navLinks.map((link) => (
098                <button
099                  key={link.href}
100                  onClick={() => handleNavClick(link.href)}
101                  className="text-[#AFDCF9] hover:text-white text-base font-medium text-left transition-colors"
102                >
103                  {link.label}
104                </button>
105              ))}
106              <a
107                href="#install"
107                onClick={(e) => { e.preventDefault(); handleNavClick("#install"); }}
108                className="mt-2 px-5 py-2.5 bg-[#1D9BEE] text-white text-sm font-semibold rounded-lg text-center"
109              >
110                Começar agora
111              </a>
112            </div>
113          )}
114        </div>
115      </header>
116    );
117  }
```

---

## 🔍 Explicação Detalhada

### **Linhas 1-4: Comentário de Documentação**

```tsx
/* ============================================================
   Navbar — AssistiView SDK Landing Page
   Design: "Signal & Structure" — sticky, blur backdrop, logo + nav links
   ============================================================ */
```

**O que é?** Um comentário que documenta o propósito do componente.

**Por que?** Ajuda você e outros desenvolvedores a entender rapidamente o que o componente faz.

---

### **Linha 6: Imports**

```tsx
import { useState, useEffect } from "react";
```

**O que é?** Importar dois **hooks** do React:
- `useState` — gerenciar estado (dados que mudam)
- `useEffect` — executar código quando o componente monta/atualiza

**Analogia:** Como trazer ferramentas de uma caixa de ferramentas.

---

### **Linha 8: Constante da Logo**

```tsx
const LOGO_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663441144974/Myyhi5NYLkCckQXr947Qbj/logo-assistiview_217f65cf.png";
```

**O que é?** Uma variável que armazena a URL da logo hospedada no CDN.

**Por que constante?** Porque a URL não muda durante a execução do programa.

**Vantagem:** Se precisar mudar a URL, você muda em um único lugar.

---

### **Linhas 10-15: Array de Links**

```tsx
const navLinks = [
  { label: "Recursos", href: "#features" },
  { label: "Como funciona", href: "#how-it-works" },
  { label: "Instalação", href: "#install" },
  { label: "Documentação", href: "#docs" },
];
```

**O que é?** Um array de objetos. Cada objeto tem:
- `label` — texto que aparece no navegador
- `href` — âncora para scroll suave

**Por que?** Facilita adicionar/remover links sem mexer no JSX.

**Exemplo:** Se quiser adicionar um novo link:
```tsx
const navLinks = [
  { label: "Recursos", href: "#features" },
  { label: "Blog", href: "#blog" },  // ← Novo link
  // ...
];
```

---

### **Linha 17: Exportar Componente**

```tsx
export default function Navbar() {
```

**O que é?** Declarar a função `Navbar` como componente React.

**`export default`?** Significa que este é o componente principal do arquivo.

**Como usar?** Em outro arquivo:
```tsx
import Navbar from "@/components/Navbar";

export default function Home() {
  return (
    <>
      <Navbar />
      {/* resto da página */}
    </>
  );
}
```

---

### **Linhas 19-21: Estados**

```tsx
const [scrolled, setScrolled] = useState(false);
const [menuOpen, setMenuOpen] = useState(false);
```

**O que é?** Criar dois estados:
1. `scrolled` — boolean que diz se a página foi scrollada
2. `menuOpen` — boolean que diz se o menu mobile está aberto

**Como funciona?**
```tsx
const [valor, setValor] = useState(valorInicial);
```

- `valor` — o estado atual
- `setValor` — função para atualizar o estado
- `valorInicial` — valor quando o componente monta (aqui: `false`)

**Exemplo de uso:**
```tsx
// Ler o estado
console.log(scrolled); // false

// Atualizar o estado
setScrolled(true); // Agora scrolled = true
```

---

### **Linhas 24-28: useEffect para Detectar Scroll**

```tsx
useEffect(() => {
  const handleScroll = () => setScrolled(window.scrollY > 20);
  window.addEventListener("scroll", handleScroll);
  return () => window.removeEventListener("scroll", handleScroll);
}, []);
```

**O que faz?** Detecta quando o usuário scrollou mais de 20px e atualiza o estado.

**Linha por linha:**

| Linha | O que faz |
|-------|----------|
| `useEffect(() => { ... }, [])` | Executar código quando o componente monta ([] = dependências vazias = executa 1x) |
| `const handleScroll = () => ...` | Criar função que verifica se `window.scrollY > 20` |
| `window.addEventListener("scroll", handleScroll)` | Adicionar listener de scroll |
| `return () => window.removeEventListener(...)` | Cleanup: remover listener quando componente desmonta |

**Por que cleanup?** Evitar memory leaks (vazamento de memória).

**Fluxo:**
1. Usuário abre a página
2. `useEffect` executa e adiciona listener de scroll
3. Usuário scrolls
4. `handleScroll` é chamado
5. Se scrollou > 20px: `setScrolled(true)`
6. Componente re-renderiza com fundo escuro
7. Usuário fecha a página
8. Cleanup remove o listener

---

### **Linhas 31-35: Função de Scroll Suave**

```tsx
const handleNavClick = (href: string) => {
  setMenuOpen(false);
  const el = document.querySelector(href);
  if (el) el.scrollIntoView({ behavior: "smooth" });
};
```

**O que faz?** Quando clica em um link, faz scroll suave para a seção.

**Linha por linha:**

| Linha | O que faz |
|-------|----------|
| `const handleNavClick = (href: string) => { ... }` | Função que recebe uma string (ex: "#features") |
| `setMenuOpen(false)` | Fechar menu mobile |
| `const el = document.querySelector(href)` | Encontrar elemento com ID igual ao href |
| `if (el) el.scrollIntoView({ behavior: "smooth" })` | Se elemento existe, scroll suave até ele |

**Exemplo:**
```tsx
// Usuário clica em "Recursos"
handleNavClick("#features");

// A função:
// 1. Fecha menu mobile
// 2. Encontra elemento com id="features"
// 3. Faz scroll suave até ele
```

---

### **Linhas 38-44: Header com Fundo Dinâmico**

```tsx
<header
  className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
    scrolled
      ? "bg-[#041723]/90 backdrop-blur-md border-b border-[#1D9BEE]/20 shadow-lg shadow-[#1D9BEE]/5"
      : "bg-transparent"
  }`}
>
```

**O que faz?** Header que muda de estilo baseado no estado `scrolled`.

**Classes Tailwind:**

| Classe | O que faz |
|--------|----------|
| `fixed` | Fixo na tela (não scrolls) |
| `top-0 left-0 right-0` | Esticar para os lados |
| `z-50` | Aparecer acima de tudo |
| `transition-all duration-300` | Transição suave de 300ms |
| `bg-[#041723]/90` | Fundo azul escuro com 90% de opacidade |
| `backdrop-blur-md` | Blur no fundo (efeito vidro) |
| `border-b` | Borda na base |
| `border-[#1D9BEE]/20` | Borda azul com 20% de opacidade |
| `shadow-lg shadow-[#1D9BEE]/5` | Sombra grande com cor azul |
| `bg-transparent` | Sem fundo (quando não scrollou) |

**Lógica:**
```tsx
scrolled ? "com fundo" : "sem fundo"
```

Se `scrolled = true` → fundo escuro + blur
Se `scrolled = false` → transparente

---

### **Linhas 46-56: Logo**

```tsx
<a
  href="#"
  className="flex items-center gap-2"
  aria-label="AssistiView SDK — Página inicial"
>
  <img
    src={LOGO_URL}
    alt="AssistiView SDK"
    className="h-8 md:h-10 w-auto"
  />
</a>
```

**O que faz?** Link clicável com a logo.

**Atributos:**

| Atributo | O que faz |
|----------|----------|
| `href="#"` | Link para topo da página |
| `aria-label` | Acessibilidade: descreve o link para leitores de tela |
| `src={LOGO_URL}` | Usar a constante de URL |
| `alt="AssistiView SDK"` | Texto alternativo se imagem não carrega |
| `h-8 md:h-10` | 8 unidades em mobile, 10 em desktop |
| `w-auto` | Largura automática (mantém proporção) |

---

### **Linhas 59-69: Links de Desktop**

```tsx
<div className="hidden md:flex items-center gap-8">
  {navLinks.map((link) => (
    <button
      key={link.href}
      onClick={() => handleNavClick(link.href)}
      className="text-[#AFDCF9] hover:text-white text-sm font-medium transition-colors duration-200 relative group"
    >
      {link.label}
      <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-[#1D9BEE] transition-all duration-300 group-hover:w-full" />
    </button>
  ))}
</div>
```

**O que faz?** Mostrar links de navegação no desktop (hidden em mobile).

**Linha por linha:**

| Linha | O que faz |
|-------|----------|
| `hidden md:flex` | Escondido em mobile, visível em desktop |
| `navLinks.map((link) => ...)` | Loop: para cada link, criar um botão |
| `key={link.href}` | React precisa de chave única para cada item |
| `onClick={() => handleNavClick(...)}` | Chamar função de scroll suave |
| `relative group` | Posicionamento relativo + grupo para hover |
| `{link.label}` | Mostrar texto do link |
| `<span>` | Underline que aparece no hover |
| `w-0 group-hover:w-full` | Underline começa com 0px, expande no hover |

**Resultado visual:**
```
Recursos  ← Hover aqui
         ▔▔▔▔▔▔▔▔▔  ← Underline azul aparece
```

---

### **Linhas 72-80: Botão CTA (Desktop)**

```tsx
<div className="hidden md:flex items-center gap-4">
  <a
    href="#install"
    onClick={(e) => { e.preventDefault(); handleNavClick("#install"); }}
    className="px-5 py-2 bg-[#1D9BEE] hover:bg-[#1883CA] text-white text-sm font-semibold rounded-lg transition-all duration-200 hover:shadow-lg hover:shadow-[#1D9BEE]/30"
  >
    Começar agora
  </a>
</div>
```

**O que faz?** Botão "Começar agora" que aparece apenas no desktop.

**`onClick={(e) => { e.preventDefault(); ... }}`?**
- `e.preventDefault()` — evita comportamento padrão do link (ir para URL)
- Usa `handleNavClick` para scroll suave em vez disso

---

### **Linhas 83-91: Hamburger Menu (Mobile)**

```tsx
<button
  className="md:hidden flex flex-col gap-1.5 p-2"
  onClick={() => setMenuOpen(!menuOpen)}
  aria-label={menuOpen ? "Fechar menu" : "Abrir menu"}
>
  <span className={`block w-6 h-0.5 bg-[#AFDCF9] transition-all duration-300 ${menuOpen ? "rotate-45 translate-y-2" : ""}`} />
  <span className={`block w-6 h-0.5 bg-[#AFDCF9] transition-all duration-300 ${menuOpen ? "opacity-0" : ""}`} />
  <span className={`block w-6 h-0.5 bg-[#AFDCF9] transition-all duration-300 ${menuOpen ? "-rotate-45 -translate-y-2" : ""}`} />
</button>
```

**O que faz?** Botão de hamburger que aparece apenas em mobile.

**Animação:**
- Linha 1: Rotaciona 45° para cima
- Linha 2: Desaparece (opacity-0)
- Linha 3: Rotaciona -45° para baixo

**Resultado:** As 3 linhas viram um X quando clica.

---

### **Linhas 95-113: Menu Mobile**

```tsx
{menuOpen && (
  <div className="md:hidden bg-[#041723]/95 backdrop-blur-md border-t border-[#1D9BEE]/20 py-4 flex flex-col gap-4 px-4">
    {navLinks.map((link) => (
      <button
        key={link.href}
        onClick={() => handleNavClick(link.href)}
        className="text-[#AFDCF9] hover:text-white text-base font-medium text-left transition-colors"
      >
        {link.label}
      </button>
    ))}
    <a
      href="#install"
      onClick={(e) => { e.preventDefault(); handleNavClick("#install"); }}
      className="mt-2 px-5 py-2.5 bg-[#1D9BEE] text-white text-sm font-semibold rounded-lg text-center"
    >
      Começar agora
    </a>
  </div>
)}
```

**O que faz?** Menu que aparece apenas quando `menuOpen = true` e apenas em mobile.

**`{menuOpen && (...)}` ?** Renderização condicional:
- Se `menuOpen = true` → mostrar menu
- Se `menuOpen = false` → não mostrar nada

---

## 🎯 Resumo Executivo

| Conceito | O que é | Exemplo |
|----------|--------|---------|
| **useState** | Gerenciar estado | `const [scrolled, setScrolled] = useState(false)` |
| **useEffect** | Executar código ao montar | `useEffect(() => { ... }, [])` |
| **.map()** | Loop sobre array | `navLinks.map((link) => ...)` |
| **Condicional** | If/else em JSX | `scrolled ? "com fundo" : "sem fundo"` |
| **Tailwind** | Classes CSS | `bg-[#041723] hover:bg-[#1883CA]` |
| **Responsividade** | Mobile/Desktop | `hidden md:flex` |

---

## 🚀 Próximos Passos

1. ✅ Entender Navbar
2. 📖 Estudar Hero.tsx (seção principal)
3. 📦 Estudar Features.tsx (grid de cards)
4. 🔧 Estudar InstallSection.tsx (tabs de código)

Qual você quer aprender próximo? 👇
