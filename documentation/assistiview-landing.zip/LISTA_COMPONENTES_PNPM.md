# 📦 Lista Completa de Componentes para Instalar com pnpm

## ⚡ Quick Start

Se você quer instalar TUDO de uma vez, execute:

```bash
pnpm install
```

Isso vai instalar todas as 65 dependências automaticamente usando o `package.json`.

---

## 📋 Se Você Quiser Instalar Manualmente

### Opção 1: Instalar Tudo de Uma Vez (Recomendado)

```bash
pnpm install
```

### Opção 2: Instalar por Categoria

#### 🎨 **UI & Styling** (Tailwind + Radix UI)

```bash
pnpm add tailwindcss@4.1.14
pnpm add @tailwindcss/vite@4.1.3
pnpm add @tailwindcss/typography@0.5.15
pnpm add tailwindcss-animate@1.0.7
pnpm add tw-animate-css@1.4.0
pnpm add tailwind-merge@3.3.1
pnpm add -D postcss@8.4.47
pnpm add -D autoprefixer@10.4.20
```

**Radix UI Components (22 componentes):**

```bash
pnpm add @radix-ui/react-accordion@1.2.12
pnpm add @radix-ui/react-alert-dialog@1.1.15
pnpm add @radix-ui/react-aspect-ratio@1.1.7
pnpm add @radix-ui/react-avatar@1.1.10
pnpm add @radix-ui/react-checkbox@1.3.3
pnpm add @radix-ui/react-collapsible@1.1.12
pnpm add @radix-ui/react-context-menu@2.2.16
pnpm add @radix-ui/react-dialog@1.1.15
pnpm add @radix-ui/react-dropdown-menu@2.1.16
pnpm add @radix-ui/react-hover-card@1.1.15
pnpm add @radix-ui/react-label@2.1.7
pnpm add @radix-ui/react-menubar@1.1.16
pnpm add @radix-ui/react-navigation-menu@1.2.14
pnpm add @radix-ui/react-popover@1.1.15
pnpm add @radix-ui/react-progress@1.1.7
pnpm add @radix-ui/react-radio-group@1.3.8
pnpm add @radix-ui/react-scroll-area@1.2.10
pnpm add @radix-ui/react-select@2.2.6
pnpm add @radix-ui/react-separator@1.1.7
pnpm add @radix-ui/react-slider@1.3.6
pnpm add @radix-ui/react-slot@1.2.3
pnpm add @radix-ui/react-switch@1.2.6
pnpm add @radix-ui/react-tabs@1.1.13
pnpm add @radix-ui/react-toggle@1.1.10
pnpm add @radix-ui/react-toggle-group@1.1.11
pnpm add @radix-ui/react-tooltip@1.2.8
```

#### ⚛️ **React & Core**

```bash
pnpm add react@19.2.1
pnpm add react-dom@19.2.1
pnpm add wouter@3.3.5
```

#### 🎬 **Animações & Motion**

```bash
pnpm add framer-motion@12.23.22
```

#### 📝 **Formulários & Validação**

```bash
pnpm add react-hook-form@7.64.0
pnpm add @hookform/resolvers@5.2.2
pnpm add zod@4.1.12
```

#### 🎯 **Ícones & Utilitários**

```bash
pnpm add lucide-react@0.453.0
pnpm add clsx@2.1.1
pnpm add class-variance-authority@0.7.1
pnpm add nanoid@5.1.5
pnpm add axios@1.12.0
```

#### 🎨 **Temas & Markdown**

```bash
pnpm add next-themes@0.4.6
pnpm add streamdown@1.4.0
pnpm add sonner@2.0.7
```

#### 🔧 **Dev Dependencies**

```bash
pnpm add -D vite@7.1.7
pnpm add -D @vitejs/plugin-react@5.0.4
pnpm add -D typescript@5.6.3
pnpm add -D prettier@3.6.2
pnpm add -D esbuild@0.25.0
pnpm add -D @types/react@19.2.1
pnpm add -D @types/react-dom@19.2.1
pnpm add -D @types/node@24.7.0
pnpm add -D @types/express@4.17.21
pnpm add -D @builder.io/vite-plugin-jsx-loc@0.1.1
pnpm add -D tsx@4.19.1
pnpm add -D vitest@2.1.4
pnpm add -D @types/google.maps@3.58.1
```

#### 🖥️ **Backend (Express)**

```bash
pnpm add express@4.21.2
```

---

## 📊 Tabela Completa de Dependências

| Categoria | Pacote | Versão | Tipo | Propósito |
|-----------|--------|--------|------|----------|
| **UI** | tailwindcss | 4.1.14 | dep | Framework CSS |
| **UI** | @tailwindcss/vite | 4.1.3 | dev | Plugin Vite |
| **UI** | @tailwindcss/typography | 0.5.15 | dev | Estilos de texto |
| **UI** | tailwindcss-animate | 1.0.7 | dep | Animações |
| **UI** | tw-animate-css | 1.4.0 | dev | Mais animações |
| **UI** | tailwind-merge | 3.3.1 | dep | Merge de classes |
| **UI** | @radix-ui/react-* | v1.x | dep | 22 componentes |
| **React** | react | 19.2.1 | dep | Biblioteca |
| **React** | react-dom | 19.2.1 | dep | Renderização |
| **React** | wouter | 3.3.5 | dep | Roteamento |
| **Motion** | framer-motion | 12.23.22 | dep | Animações |
| **Forms** | react-hook-form | 7.64.0 | dep | Formulários |
| **Forms** | @hookform/resolvers | 5.2.2 | dep | Validação |
| **Forms** | zod | 4.1.12 | dep | Schema validation |
| **Icons** | lucide-react | 0.453.0 | dep | Ícones SVG |
| **Utils** | clsx | 2.1.1 | dep | Merge classes |
| **Utils** | class-variance-authority | 0.7.1 | dep | Variantes |
| **Utils** | nanoid | 5.1.5 | dep | IDs únicas |
| **Utils** | axios | 1.12.0 | dep | HTTP client |
| **Theme** | next-themes | 0.4.6 | dep | Tema dark/light |
| **Markdown** | streamdown | 1.4.0 | dep | Markdown render |
| **Toast** | sonner | 2.0.7 | dep | Notificações |
| **Build** | vite | 7.1.7 | dev | Build tool |
| **Build** | @vitejs/plugin-react | 5.0.4 | dev | Plugin React |
| **Build** | esbuild | 0.25.0 | dev | Bundler |
| **Types** | typescript | 5.6.3 | dev | Tipagem |
| **Types** | @types/react | 19.2.1 | dev | Types React |
| **Types** | @types/react-dom | 19.2.1 | dev | Types React DOM |
| **Types** | @types/node | 24.7.0 | dev | Types Node |
| **Types** | @types/express | 4.17.21 | dev | Types Express |
| **Format** | prettier | 3.6.2 | dev | Formatador |
| **CSS** | postcss | 8.4.47 | dev | CSS processor |
| **CSS** | autoprefixer | 10.4.20 | dev | Prefixos CSS |
| **Server** | express | 4.21.2 | dep | Framework web |

---

## 🚀 Passo a Passo para Instalar

### Método 1: Automático (Recomendado)

```bash
# 1. Entre no diretório do projeto
cd /home/ubuntu/assistiview-landing

# 2. Instale todas as dependências
pnpm install

# 3. Verifique se tudo foi instalado
pnpm list

# 4. Inicie o servidor
pnpm dev
```

### Método 2: Manual (Se Quiser Aprender)

```bash
# 1. Instale Tailwind + Vite
pnpm add tailwindcss@4.1.14 @tailwindcss/vite@4.1.3 -D

# 2. Instale React
pnpm add react@19.2.1 react-dom@19.2.1

# 3. Instale Radix UI (componentes)
pnpm add @radix-ui/react-dialog@1.1.15 @radix-ui/react-dropdown-menu@2.1.16

# 4. Instale ícones
pnpm add lucide-react@0.453.0

# 5. Instale roteamento
pnpm add wouter@3.3.5

# 6. Instale animações
pnpm add framer-motion@12.23.22

# 7. Instale TypeScript
pnpm add -D typescript@5.6.3

# 8. Instale Prettier
pnpm add -D prettier@3.6.2

# 9. Verifique
pnpm check

# 10. Rode
pnpm dev
```

---

## 🔍 Verificar Instalação

### Ver todas as dependências instaladas

```bash
pnpm list
```

### Ver apenas as dependências principais

```bash
pnpm list --depth=0
```

### Ver tamanho das dependências

```bash
pnpm list --depth=0 | grep -E "^├|^└"
```

### Verificar se há atualizações disponíveis

```bash
pnpm outdated
```

---

## 🧹 Limpar & Reinstalar

Se algo der errado:

```bash
# Remover node_modules e lock file
rm -rf node_modules
rm pnpm-lock.yaml

# Reinstalar
pnpm install

# Ou forçar reinstalação
pnpm install --force
```

---

## 📦 Tamanho Total

Todas as 65 dependências ocupam aproximadamente:

- **node_modules:** ~800 MB
- **pnpm-lock.yaml:** ~5 MB
- **package.json:** ~3 KB

---

## ✅ Checklist de Instalação

- [ ] Node.js v18+ instalado
- [ ] pnpm instalado globalmente
- [ ] Entrou no diretório do projeto
- [ ] Executou `pnpm install`
- [ ] Executou `pnpm check` (sem erros)
- [ ] Executou `pnpm dev`
- [ ] Abriu http://localhost:3000
- [ ] Landing page apareceu no navegador

---

## 🆘 Troubleshooting

### ❌ "pnpm: command not found"

```bash
npm install -g pnpm
```

### ❌ "Cannot find module 'react'"

```bash
pnpm install --force
```

### ❌ "Port 3000 already in use"

```bash
pnpm dev -- --port 3001
```

### ❌ "TypeScript compilation error"

```bash
pnpm check
pnpm format
```

---

## 📚 Próximos Passos

1. ✅ Instalar dependências
2. ✅ Rodar servidor
3. 📖 Estudar componentes (Navbar, Hero, Features, etc.)
4. 🎨 Customizar cores e tipografia
5. 📝 Adicionar novo conteúdo

---

**Pronto para instalar?** Execute:

```bash
cd /home/ubuntu/assistiview-landing && pnpm install && pnpm dev
```

🚀
