# 🎨 Guia de CSS Global & Design System — AssistiView SDK

## O que é um Design System?

Um **design system** é um conjunto de regras, cores, tipografia e componentes reutilizáveis que garantem consistência visual em todo o projeto. É como um "manual de identidade visual" para código.

**Arquivo principal:** `client/src/index.css`

---

## 📋 Índice

1. [Estrutura do index.css](#estrutura-do-indexcss)
2. [Paleta de Cores](#paleta-de-cores)
3. [Tipografia](#tipografia)
4. [Animações Customizadas](#animações-customizadas)
5. [Layers do Tailwind](#layers-do-tailwind)
6. [Variáveis CSS (CSS Variables)](#variáveis-css)
7. [Exemplo Prático: Criar um Novo Componente](#exemplo-prático-criar-um-novo-componente)

---

## Estrutura do index.css

O arquivo `index.css` tem **5 seções principais**:

```css
/* 1. Imports */
@import "tailwindcss";
@import "tw-animate-css";

/* 2. Custom variants */
@custom-variant dark (&:is(.dark *));

/* 3. Theme inline (Tailwind 4) */
@theme inline { ... }

/* 4. Root variables */
:root { ... }

/* 5. Layers (base, components, utilities) */
@layer base { ... }
@layer components { ... }
```

---

## 🎨 Paleta de Cores

### Extração da Logomarca

A cor primária **#1D9BEE** foi extraída da logomarca e expandida em 11 tons:

```
av-blue-50:   #ECF7FD  ← Mais claro (backgrounds sutis)
av-blue-100:  #D6EDFB
av-blue-200:  #AFDCF9  ← Texto sobre fundos escuros
av-blue-300:  #82C8F5  ← Syntax highlight
av-blue-400:  #4EB1F1  ← Links hover
av-blue-500:  #1D9BEE  ← PRIMÁRIA (logo)
av-blue-600:  #1883CA  ← Botões hover
av-blue-700:  #146CA6  ← Botões ativos
av-blue-800:  #0E4D77  ← Seções destaque
av-blue-900:  #082E47  ← Hero background
av-blue-950:  #041723  ← Mais escuro (footer)
```

### Como Usar no Código

**Em Tailwind (classes):**
```jsx
<div className="bg-av-blue-50">Fundo claro</div>
<div className="text-av-blue-500">Texto azul primário</div>
<button className="bg-av-blue-600 hover:bg-av-blue-700">Botão</button>
```

**Em CSS puro:**
```css
.meu-elemento {
  background-color: var(--color-av-blue-50);
  color: var(--color-av-blue-500);
}
```

### Onde Está Definida?

No `index.css`, seção `@theme inline`:

```css
@theme inline {
  --color-av-blue-50: #ECF7FD;
  --color-av-blue-100: #D6EDFB;
  --color-av-blue-200: #AFDCF9;
  --color-av-blue-300: #82C8F5;
  --color-av-blue-400: #4EB1F1;
  --color-av-blue-500: #1D9BEE;
  --color-av-blue-600: #1883CA;
  --color-av-blue-700: #146CA6;
  --color-av-blue-800: #0E4D77;
  --color-av-blue-900: #082E47;
  --color-av-blue-950: #041723;
}
```

---

## 🔤 Tipografia

### Fontes Importadas

No `client/index.html`:

```html
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,600;1,9..40,300&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet" />
```

### Atribuição de Fontes

No `index.css`, `@layer base`:

```css
body {
  font-family: 'DM Sans', sans-serif;  /* Corpo de texto */
}

h1, h2, h3, h4, h5, h6 {
  font-family: 'Syne', sans-serif;     /* Títulos */
}

code, pre, .font-mono {
  font-family: 'JetBrains Mono', monospace;  /* Código */
}
```

### Hierarquia de Tipografia

| Elemento | Fonte | Peso | Tamanho | Uso |
|----------|-------|------|---------|-----|
| `<h1>` | Syne | 800 (ExtraBold) | 3.75rem (60px) | Títulos principais |
| `<h2>` | Syne | 700 (Bold) | 2.25rem (36px) | Subtítulos |
| `<h3>` | Syne | 600 (SemiBold) | 1.875rem (30px) | Títulos de seção |
| `<p>` | DM Sans | 400 (Regular) | 1rem (16px) | Corpo de texto |
| `<small>` | DM Sans | 300 (Light) | 0.875rem (14px) | Texto pequeno |
| `<code>` | JetBrains Mono | 400 | 0.875rem (14px) | Código inline |
| `<pre>` | JetBrains Mono | 400 | 0.875rem (14px) | Bloco de código |

### Exemplo de Uso

```jsx
// Em um componente React
<h1 style={{ fontFamily: "Syne, sans-serif" }} className="text-5xl font-extrabold">
  Acessibilidade nativa
</h1>

<p className="text-lg leading-relaxed">
  Parágrafo em DM Sans (aplicado automaticamente pelo body)
</p>

<code className="font-mono text-sm">
  const x = 42;
</code>
```

---

## ✨ Animações Customizadas

### Animações Definidas

No `index.css`, `@layer components`:

```css
@keyframes slideInLeft {
  from { opacity: 0; transform: translateX(-30px); }
  to { opacity: 1; transform: translateX(0); }
}

@keyframes slideInRight {
  from { opacity: 0; transform: translateX(30px); }
  to { opacity: 1; transform: translateX(0); }
}

@keyframes fadeInUp {
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
}

@keyframes float {
  0%, 100% { transform: translateY(0px) rotate(-5deg); }
  50% { transform: translateY(-12px) rotate(-5deg); }
}

@keyframes pulse-dot {
  0%, 100% { opacity: 0.3; transform: scale(1); }
  50% { opacity: 0.8; transform: scale(1.3); }
}

@keyframes glow {
  0%, 100% { box-shadow: 0 0 20px #1D9BEE44; }
  50% { box-shadow: 0 0 40px #1D9BEE88, 0 0 60px #1D9BEE33; }
}
```

### Classes de Animação

```css
.animate-float {
  animation: float 4s ease-in-out infinite;
}

.animate-pulse-dot {
  animation: pulse-dot 2s ease-in-out infinite;
}

.animate-glow {
  animation: glow 3s ease-in-out infinite;
}

.animate-fade-in-up {
  animation: fadeInUp 0.6s ease-out forwards;
}

.animate-slide-in-left {
  animation: slideInLeft 0.6s ease-out forwards;
}

.animate-slide-in-right {
  animation: slideInRight 0.6s ease-out forwards;
}
```

### Como Usar

```jsx
// Mockup flutuando
<div className="animate-float">
  <img src="phone-mockup.png" alt="Mockup" />
</div>

// Pontos Braille pulsando
<div className="animate-pulse-dot" />

// Glow ao redor de elemento
<div className="animate-glow" />

// Fade in ao entrar na viewport
<div className="animate-fade-in-up">
  Conteúdo que aparece
</div>
```

---

## 🏗️ Layers do Tailwind

Tailwind organiza CSS em 3 camadas:

### 1. `@layer base`
Estilos fundamentais (reset, body, button)

```css
@layer base {
  * {
    @apply border-border outline-ring/50;  /* Todos elementos */
  }
  body {
    @apply bg-background text-foreground;  /* Fundo e texto */
  }
  button:not(:disabled) {
    @apply cursor-pointer;  /* Botões clicáveis */
  }
}
```

**Quando usar:** Estilos que afetam TUDO (reset, defaults)

### 2. `@layer components`
Componentes reutilizáveis (`.container`, `.code-block`, `.gradient-border`)

```css
@layer components {
  .container {
    width: 100%;
    margin-left: auto;
    margin-right: auto;
    padding-left: 1rem;
  }

  .code-block {
    font-family: 'JetBrains Mono', monospace;
    background-color: #041723;
    border: 1px solid #1D9BEE33;
    border-radius: 0.75rem;
    padding: 1.5rem;
  }

  .gradient-border {
    position: relative;
    background: linear-gradient(#041723, #041723) padding-box,
                linear-gradient(135deg, #1D9BEE, #4EB1F1) border-box;
    border: 1px solid transparent;
  }
}
```

**Quando usar:** Classes reutilizáveis em múltiplos componentes

### 3. `@layer utilities`
Utilitários (classes únicas para casos específicos)

```css
@layer utilities {
  .text-shadow-sm {
    text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.1);
  }
}
```

**Quando usar:** Estilos únicos que não se repetem

---

## 🔧 Variáveis CSS

### Definição

No `index.css`, dentro de `:root`:

```css
:root {
  --radius: 0.5rem;
  --background: oklch(1 0 0);
  --foreground: oklch(0.12 0.02 240);
  --primary: oklch(0.60 0.17 230);
  --primary-foreground: oklch(1 0 0);
}
```

### Formato OKLCH

`oklch(lightness saturation hue)`

- **Lightness:** 0 (preto) a 1 (branco)
- **Saturation:** 0 (sem cor) a 1 (cor pura)
- **Hue:** 0-360 (ângulo na roda de cores)

**Exemplo:**
```css
--primary: oklch(0.60 0.17 230);
/* 60% de luminosidade, 17% de saturação, azul (230°) */
```

### Uso em Componentes

```jsx
// Tailwind automaticamente usa as variáveis
<button className="bg-primary text-primary-foreground">
  Clique aqui
</button>

// Ou em CSS puro
<div style={{ backgroundColor: "var(--primary)" }}>
  Fundo primário
</div>
```

---

## 📝 Exemplo Prático: Criar um Novo Componente

Vamos criar um **Card de Testimonial** do zero:

### Passo 1: Definir a Estrutura HTML

```jsx
// components/TestimonialCard.tsx
export default function TestimonialCard() {
  return (
    <div className="rounded-2xl border border-[#ECF7FD] bg-white p-6">
      {/* Avatar */}
      <div className="flex items-center gap-4 mb-4">
        <img src="avatar.jpg" alt="Pessoa" className="w-12 h-12 rounded-full" />
        <div>
          <h4 className="font-bold text-[#082E47]">João Silva</h4>
          <p className="text-sm text-[#4A6070]">Desenvolvedor Android</p>
        </div>
      </div>

      {/* Citação */}
      <p className="text-[#4A6070] leading-relaxed mb-4">
        "O AssistiView SDK tornou a acessibilidade trivial. Integrei em 10 minutos!"
      </p>

      {/* Stars */}
      <div className="flex gap-1">
        {Array.from({ length: 5 }).map((_, i) => (
          <span key={i} className="text-[#1D9BEE]">★</span>
        ))}
      </div>
    </div>
  );
}
```

### Passo 2: Adicionar Animação ao Scroll

```jsx
import { useEffect, useRef, useState } from "react";

export default function TestimonialCard() {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setVisible(true); },
      { threshold: 0.15 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <div
      ref={ref}
      className={`rounded-2xl border border-[#ECF7FD] bg-white p-6 transition-all duration-500 ${
        visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"
      }`}
    >
      {/* ... conteúdo ... */}
    </div>
  );
}
```

### Passo 3: Adicionar Hover Effect

```jsx
<div
  ref={ref}
  className={`rounded-2xl border border-[#ECF7FD] hover:border-[#1D9BEE]/40 bg-white p-6 transition-all duration-300 hover:shadow-xl hover:shadow-[#1D9BEE]/10 hover:-translate-y-1 ${
    visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"
  }`}
>
  {/* ... conteúdo ... */}
</div>
```

### Passo 4: Usar em Home.tsx

```jsx
import TestimonialCard from "@/components/TestimonialCard";

export default function Home() {
  return (
    <section className="py-24 bg-white">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <TestimonialCard />
          <TestimonialCard />
          <TestimonialCard />
        </div>
      </div>
    </section>
  );
}
```

---

## 🎯 Checklist de Design System

- ✅ **Cores:** Paleta de 11 tons de azul definida
- ✅ **Tipografia:** 3 fontes (Syne, DM Sans, JetBrains Mono)
- ✅ **Animações:** 6 animações customizadas
- ✅ **Spacing:** Escala de espaçamento Tailwind padrão
- ✅ **Border Radius:** `0.5rem` (8px) como padrão
- ✅ **Shadows:** Sombras sutis com azul primário
- ✅ **Layers:** Base, Components, Utilities bem organizadas
- ✅ **Variáveis CSS:** OKLCH para cores semânticas

---

## 📚 Referências

- [Tailwind CSS Docs](https://tailwindcss.com/docs)
- [OKLCH Color Space](https://oklch.com/)
- [CSS Variables (MDN)](https://developer.mozilla.org/en-US/docs/Web/CSS/--*)
- [CSS Animations (MDN)](https://developer.mozilla.org/en-US/docs/Web/CSS/animation)

---

**Próximo passo?** Estude o `Navbar.tsx` ou `Hero.tsx` para ver como esses estilos são aplicados em componentes reais! 🚀
