/* ============================================================
   HowItWorks — AssistiView SDK Landing Page
   Design: "Signal & Structure"
   - Fundo av-blue-50 com seção alternada
   - Ilustração à esquerda, texto à direita
   - Steps numerados com linha conectora
   ============================================================ */

import { useEffect, useRef, useState } from "react";

const ILLUSTRATION = "https://d2xsxph8kpxj0f.cloudfront.net/310519663441144974/Myyhi5NYLkCckQXr947Qbj/accessibility-illustration-VsdgZtBkBCVBeHKRjrTGXJ.webp";

const steps = [
  {
    number: "01",
    title: "Adicione a dependência",
    description:
      "Inclua o AssistiView SDK no seu arquivo build.gradle.kts com uma única linha. Disponível via Maven Central — sem configuração adicional de repositório.",
    code: `implementation("io.assistiview:sdk:1.0.0")`,
  },
  {
    number: "02",
    title: "Inicialize no Application",
    description:
      "Configure o SDK na sua classe Application com as opções desejadas. Ative o modo debug para auditoria de acessibilidade em tempo real durante o desenvolvimento.",
    code: `AssistiView.init(this) {\n  debugMode = BuildConfig.DEBUG\n  language = "pt-BR"\n}`,
  },
  {
    number: "03",
    title: "Anote suas Views",
    description:
      "Use as extensões Kotlin para adicionar descrições, ações e comportamentos de acessibilidade diretamente nas suas Views ou Composables.",
    code: `myButton.assistiView {\n  contentDescription("Enviar formulário")\n  role(Role.Button)\n  announce("Formulário enviado!")\n}`,
  },
  {
    number: "04",
    title: "Teste com o TalkBack",
    description:
      "Ative o TalkBack no emulador ou dispositivo físico e navegue pela sua interface. O SDK garante que todos os elementos sejam anunciados corretamente.",
    code: `// Modo de auditoria — detecta problemas\nAssistiView.audit(rootView) { issues ->\n  issues.forEach { Log.w("A11y", it) }\n}`,
  },
];

function useIntersectionObserver(threshold = 0.15) {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setVisible(true); },
      { threshold }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [threshold]);
  return { ref, visible };
}

function StepCard({ step, index }: { step: (typeof steps)[0]; index: number }) {
  const { ref, visible } = useIntersectionObserver();

  return (
    <div
      ref={ref}
      className="relative flex gap-6"
      style={{
        opacity: visible ? 1 : 0,
        transform: visible ? "translateX(0)" : "translateX(-24px)",
        transition: `opacity 0.5s ease ${index * 0.15}s, transform 0.5s ease ${index * 0.15}s`,
      }}
    >
      {/* Step number + connector line */}
      <div className="flex flex-col items-center">
        <div className="flex-shrink-0 w-12 h-12 rounded-full bg-[#1D9BEE] text-white flex items-center justify-center font-bold text-sm" style={{ fontFamily: "Syne, sans-serif" }}>
          {step.number}
        </div>
        {index < steps.length - 1 && (
          <div className="w-0.5 flex-1 mt-2 bg-gradient-to-b from-[#1D9BEE]/60 to-[#1D9BEE]/10 min-h-8" />
        )}
      </div>

      {/* Content */}
      <div className="pb-10">
        <h3
          className="text-xl font-bold text-[#082E47] mb-2"
          style={{ fontFamily: "Syne, sans-serif" }}
        >
          {step.title}
        </h3>
        <p className="text-[#4A6070] text-sm leading-relaxed mb-4">{step.description}</p>

        {/* Code snippet */}
        <div className="rounded-xl bg-[#041723] border border-[#1D9BEE]/20 p-4 overflow-x-auto">
          <pre className="text-[#82C8F5] text-xs leading-relaxed font-mono whitespace-pre">
            <code>{step.code}</code>
          </pre>
        </div>
      </div>
    </div>
  );
}

export default function HowItWorks() {
  const { ref: titleRef, visible: titleVisible } = useIntersectionObserver();
  const { ref: imgRef, visible: imgVisible } = useIntersectionObserver();

  return (
    <section id="how-it-works" className="py-24 bg-[#ECF7FD]" aria-labelledby="how-it-works-heading">
      <div className="container">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
          {/* Left: illustration */}
          <div
            ref={imgRef}
            className="lg:sticky lg:top-24"
            style={{
              opacity: imgVisible ? 1 : 0,
              transform: imgVisible ? "translateX(0)" : "translateX(-30px)",
              transition: "opacity 0.7s ease, transform 0.7s ease",
            }}
          >
            <div
              ref={titleRef}
              className="mb-10"
              style={{
                opacity: titleVisible ? 1 : 0,
                transition: "opacity 0.6s ease",
              }}
            >
              <div className="inline-flex items-center gap-2 px-3 py-1.5 mb-4 rounded-full border border-[#1D9BEE]/30 bg-white text-[#1883CA] text-xs font-semibold tracking-wide uppercase">
                Como funciona
              </div>
              <h2
                id="how-it-works-heading"
                className="text-3xl md:text-4xl font-extrabold text-[#082E47] mb-4"
                style={{ fontFamily: "Syne, sans-serif" }}
              >
                Integre em{" "}
                <span className="text-[#1D9BEE]">4 passos simples</span>
              </h2>
              <p className="text-[#4A6070] leading-relaxed">
                Do zero à acessibilidade completa em menos de 5 minutos.
                O AssistiView SDK foi projetado para ser intuitivo para qualquer
                desenvolvedor Android com conhecimento básico de Kotlin.
              </p>
            </div>

            <div className="rounded-2xl overflow-hidden shadow-xl shadow-[#1D9BEE]/10 bg-white">
              <img
                src={ILLUSTRATION}
                alt="Pessoa com deficiência visual usando smartphone com o AssistiView SDK"
                className="w-full object-cover"
                loading="lazy"
              />
            </div>

            {/* Quote */}
            <blockquote className="mt-6 pl-4 border-l-4 border-[#1D9BEE] text-[#4A6070] text-sm italic leading-relaxed">
              "Acessibilidade não é um recurso opcional — é um direito fundamental. O AssistiView
              SDK torna esse direito mais fácil de implementar para qualquer desenvolvedor."
            </blockquote>
          </div>

          {/* Right: steps */}
          <div className="pt-2">
            {steps.map((step, index) => (
              <StepCard key={step.number} step={step} index={index} />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
