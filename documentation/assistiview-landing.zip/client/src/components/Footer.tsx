/* ============================================================
   Footer — AssistiView SDK Landing Page
   Design: "Signal & Structure"
   - Fundo av-blue-950 espelhando o hero
   - Logo + links + créditos
   ============================================================ */

const LOGO_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663441144974/Myyhi5NYLkCckQXr947Qbj/logo-assistiview_217f65cf.png";

const footerLinks = {
  SDK: [
    { label: "Instalação", href: "#install" },
    { label: "Recursos", href: "#features" },
    { label: "Como funciona", href: "#how-it-works" },
    { label: "Changelog", href: "#" },
  ],
  Documentação: [
    { label: "Guia rápido", href: "#docs" },
    { label: "Referência da API", href: "#docs" },
    { label: "Exemplos", href: "#docs" },
    { label: "FAQ", href: "#docs" },
  ],
  Comunidade: [
    { label: "GitHub", href: "https://github.com/assistiview" },
    { label: "Contribuir", href: "https://github.com/assistiview" },
    { label: "Reportar bug", href: "https://github.com/assistiview/issues" },
    { label: "Discussões", href: "https://github.com/assistiview/discussions" },
  ],
};

export default function Footer() {
  const handleNavClick = (href: string) => {
    if (href.startsWith("#")) {
      const el = document.querySelector(href);
      if (el) el.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <footer
      className="pt-16 pb-8"
      style={{ background: "linear-gradient(180deg, #041723 0%, #020D14 100%)" }}
      aria-label="Rodapé do site AssistiView SDK"
    >
      <div className="container">
        {/* Top section */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 pb-12 border-b border-[#1D9BEE]/15">
          {/* Brand */}
          <div className="lg:col-span-1">
            <a href="#" aria-label="AssistiView SDK — Topo da página">
              <img
                src={LOGO_URL}
                alt="AssistiView SDK"
                className="h-10 w-auto mb-4"
              />
            </a>
            <p className="text-[#82C8F5]/70 text-sm leading-relaxed mb-6">
              SDK Kotlin para acessibilidade nativa em Android. Tornando interfaces
              acessíveis a pessoas cegas de forma dinâmica e eficiente.
            </p>
            {/* Braille decorative */}
            <div className="flex items-center gap-3">
              <div className="grid gap-1" style={{ gridTemplateColumns: "repeat(2, 6px)" }}>
                {Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="w-1.5 h-1.5 rounded-full bg-[#1D9BEE]/50" />
                ))}
              </div>
              <span className="text-[#4EB1F1]/50 text-xs font-mono">v1.0.0 — MIT License</span>
            </div>
          </div>

          {/* Links */}
          {Object.entries(footerLinks).map(([category, links]) => (
            <div key={category}>
              <h3
                className="text-white font-semibold text-sm mb-4 uppercase tracking-wide"
                style={{ fontFamily: "Syne, sans-serif" }}
              >
                {category}
              </h3>
              <ul className="space-y-2.5">
                {links.map((link) => (
                  <li key={link.label}>
                    {link.href.startsWith("#") ? (
                      <button
                        onClick={() => handleNavClick(link.href)}
                        className="text-[#82C8F5]/70 hover:text-[#1D9BEE] text-sm transition-colors duration-200 text-left"
                      >
                        {link.label}
                      </button>
                    ) : (
                      <a
                        href={link.href}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-[#82C8F5]/70 hover:text-[#1D9BEE] text-sm transition-colors duration-200"
                      >
                        {link.label}
                      </a>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom section */}
        <div className="pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-[#4EB1F1]/40 text-xs text-center md:text-left">
            © 2025 AssistiView SDK. Distribuído sob licença MIT.
            Feito com acessibilidade em mente.
          </p>
          <div className="flex items-center gap-4">
            <span className="text-[#4EB1F1]/40 text-xs">
              Construído com Kotlin + Android Accessibility APIs
            </span>
            <div className="flex items-center gap-1.5">
              <div className="w-1.5 h-1.5 rounded-full bg-[#1D9BEE]/40" />
              <div className="w-1.5 h-1.5 rounded-full bg-[#1D9BEE]/40" />
              <div className="w-1.5 h-1.5 rounded-full bg-[#1D9BEE]/40" />
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
