/* ============================================================
   Features — AssistiView SDK Landing Page
   Design: "Signal & Structure"
   - Fundo branco com cards em av-blue-50
   - Ícones em azul primário
   - Grid 3 colunas no desktop
   ============================================================ */

import { useEffect, useRef, useState } from "react";

const features = [
  {
    icon: (
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3z"/>
        <path d="M19 10v2a7 7 0 0 1-14 0v-2"/>
        <line x1="12" y1="19" x2="12" y2="23"/>
        <line x1="8" y1="23" x2="16" y2="23"/>
      </svg>
    ),
    title: "TalkBack Nativo",
    description:
      "Integração direta com o serviço de acessibilidade TalkBack do Android. Anúncios de foco, ações customizadas e navegação por gestos funcionam automaticamente.",
    tag: "Acessibilidade",
  },
  {
    icon: (
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <polyline points="16 18 22 12 16 6"/>
        <polyline points="8 6 2 12 8 18"/>
      </svg>
    ),
    title: "API Kotlin-First",
    description:
      "Projetado para Kotlin com suporte a coroutines, extension functions e DSL fluente. Integre em qualquer View ou Composable com poucas linhas.",
    tag: "Developer Experience",
  },
  {
    icon: (
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <circle cx="12" cy="12" r="10"/>
        <path d="M12 8v4l3 3"/>
      </svg>
    ),
    title: "Navegação Dinâmica",
    description:
      "Defina a ordem de foco, grupos lógicos e hierarquias de navegação de forma programática. Usuários cegos navegam sua UI de forma fluida e previsível.",
    tag: "UX Acessível",
  },
  {
    icon: (
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
      </svg>
    ),
    title: "WCAG 2.1 AA",
    description:
      "Componentes e helpers que garantem conformidade com as diretrizes internacionais de acessibilidade web e mobile. Auditoria integrada em modo debug.",
    tag: "Conformidade",
  },
  {
    icon: (
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <rect x="2" y="3" width="20" height="14" rx="2" ry="2"/>
        <line x1="8" y1="21" x2="16" y2="21"/>
        <line x1="12" y1="17" x2="12" y2="21"/>
      </svg>
    ),
    title: "Suporte a Views e Compose",
    description:
      "Funciona tanto com o sistema de Views tradicional quanto com Jetpack Compose. Migre gradualmente sem reescrever toda a sua interface.",
    tag: "Compatibilidade",
  },
  {
    icon: (
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/>
        <polyline points="3.27 6.96 12 12.01 20.73 6.96"/>
        <line x1="12" y1="22.08" x2="12" y2="12"/>
      </svg>
    ),
    title: "Leve e Sem Dependências",
    description:
      "Zero dependências externas. O SDK adiciona menos de 50KB ao seu APK e não interfere com outras bibliotecas de UI ou frameworks de acessibilidade.",
    tag: "Performance",
  },
];

function useIntersectionObserver(threshold = 0.15) {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setVisible(true); },
      { threshold }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [threshold]);

  return { ref, visible };
}

function FeatureCard({
  feature,
  index,
}: {
  feature: (typeof features)[0];
  index: number;
}) {
  const { ref, visible } = useIntersectionObserver();

  return (
    <div
      ref={ref}
      className="group relative bg-white border border-[#ECF7FD] hover:border-[#1D9BEE]/40 rounded-2xl p-6 transition-all duration-300 hover:shadow-xl hover:shadow-[#1D9BEE]/10 hover:-translate-y-1"
      style={{
        opacity: visible ? 1 : 0,
        transform: visible ? "translateY(0)" : "translateY(24px)",
        transition: `opacity 0.5s ease ${index * 0.1}s, transform 0.5s ease ${index * 0.1}s, box-shadow 0.3s ease, border-color 0.3s ease`,
      }}
    >
      {/* Tag */}
      <div className="mb-4 inline-flex items-center px-2.5 py-1 rounded-full bg-[#ECF7FD] text-[#1883CA] text-xs font-semibold tracking-wide">
        {feature.tag}
      </div>

      {/* Icon */}
      <div className="mb-4 w-12 h-12 rounded-xl bg-[#ECF7FD] group-hover:bg-[#1D9BEE] flex items-center justify-center text-[#1D9BEE] group-hover:text-white transition-all duration-300">
        {feature.icon}
      </div>

      {/* Content */}
      <h3
        className="text-lg font-bold text-[#082E47] mb-2"
        style={{ fontFamily: "Syne, sans-serif" }}
      >
        {feature.title}
      </h3>
      <p className="text-[#4A6070] text-sm leading-relaxed">{feature.description}</p>

      {/* Hover accent line */}
      <div className="absolute bottom-0 left-6 right-6 h-0.5 bg-[#1D9BEE] scale-x-0 group-hover:scale-x-100 transition-transform duration-300 rounded-full" />
    </div>
  );
}

export default function Features() {
  const { ref: titleRef, visible: titleVisible } = useIntersectionObserver();

  return (
    <section id="features" className="py-24 bg-white" aria-labelledby="features-heading">
      <div className="container">
        {/* Section header */}
        <div
          ref={titleRef}
          className="text-center mb-16"
          style={{
            opacity: titleVisible ? 1 : 0,
            transform: titleVisible ? "translateY(0)" : "translateY(20px)",
            transition: "opacity 0.6s ease, transform 0.6s ease",
          }}
        >
          <div className="inline-flex items-center gap-2 px-3 py-1.5 mb-4 rounded-full border border-[#1D9BEE]/30 bg-[#ECF7FD] text-[#1883CA] text-xs font-semibold tracking-wide uppercase">
            Recursos
          </div>
          <h2
            id="features-heading"
            className="text-3xl md:text-4xl font-extrabold text-[#082E47] mb-4"
            style={{ fontFamily: "Syne, sans-serif" }}
          >
            Tudo que você precisa para{" "}
            <span className="text-[#1D9BEE]">construir com inclusão</span>
          </h2>
          <p className="text-[#4A6070] text-lg max-w-2xl mx-auto leading-relaxed">
            O AssistiView SDK oferece uma camada de abstração sobre as APIs nativas do Android,
            tornando a acessibilidade uma parte natural do seu fluxo de desenvolvimento.
          </p>
        </div>

        {/* Features grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <FeatureCard key={feature.title} feature={feature} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
}
