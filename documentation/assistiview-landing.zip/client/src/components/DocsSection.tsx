/* ============================================================
   DocsSection — AssistiView SDK Landing Page
   Design: "Signal & Structure"
   - Fundo branco com cards de documentação
   - Links para Docusaurus (futuro)
   - CTA final de contribuição
   ============================================================ */

const docCards = [
  {
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/>
        <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/>
      </svg>
    ),
    title: "Guia de início rápido",
    description: "Configure o AssistiView SDK do zero em menos de 5 minutos com nosso tutorial passo a passo.",
    link: "#",
    linkLabel: "Ler guia →",
    color: "from-[#ECF7FD] to-[#D6EDFB]",
  },
  {
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <polyline points="16 18 22 12 16 6"/>
        <polyline points="8 6 2 12 8 18"/>
      </svg>
    ),
    title: "Referência da API",
    description: "Documentação completa de todas as classes, funções e extensões disponíveis no SDK.",
    link: "#",
    linkLabel: "Ver API →",
    color: "from-[#D6EDFB] to-[#AFDCF9]",
  },
  {
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
        <polyline points="14 2 14 8 20 8"/>
        <line x1="16" y1="13" x2="8" y2="13"/>
        <line x1="16" y1="17" x2="8" y2="17"/>
      </svg>
    ),
    title: "Exemplos práticos",
    description: "Projetos de exemplo demonstrando casos de uso reais: formulários, listas, navegação e mais.",
    link: "#",
    linkLabel: "Ver exemplos →",
    color: "from-[#AFDCF9] to-[#82C8F5]",
  },
  {
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <circle cx="12" cy="12" r="10"/>
        <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/>
        <line x1="12" y1="17" x2="12.01" y2="17"/>
      </svg>
    ),
    title: "FAQ e solução de problemas",
    description: "Respostas para as perguntas mais frequentes e guias para resolver problemas comuns.",
    link: "#",
    linkLabel: "Ver FAQ →",
    color: "from-[#ECF7FD] to-[#D6EDFB]",
  },
];

export default function DocsSection() {
  return (
    <section id="docs" className="py-24 bg-white" aria-labelledby="docs-heading">
      <div className="container">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 mb-4 rounded-full border border-[#1D9BEE]/30 bg-[#ECF7FD] text-[#1883CA] text-xs font-semibold tracking-wide uppercase">
            Documentação
          </div>
          <h2
            id="docs-heading"
            className="text-3xl md:text-4xl font-extrabold text-[#082E47] mb-4"
            style={{ fontFamily: "Syne, sans-serif" }}
          >
            Tudo documentado,{" "}
            <span className="text-[#1D9BEE]">nada escondido</span>
          </h2>
          <p className="text-[#4A6070] text-lg max-w-2xl mx-auto leading-relaxed">
            Nossa documentação é construída com Docusaurus e mantida pela comunidade.
            Encontre guias, referências de API e exemplos práticos em um só lugar.
          </p>
        </div>

        {/* Doc cards grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-16">
          {docCards.map((card) => (
            <div
              key={card.title}
              className="group relative rounded-2xl border border-[#ECF7FD] hover:border-[#1D9BEE]/40 overflow-hidden transition-all duration-300 hover:shadow-xl hover:shadow-[#1D9BEE]/10 hover:-translate-y-1"
            >
              <div className={`absolute inset-0 bg-gradient-to-br ${card.color} opacity-40`} />
              <div className="relative p-6">
                <div className="w-11 h-11 rounded-xl bg-white shadow-sm flex items-center justify-center text-[#1D9BEE] mb-4">
                  {card.icon}
                </div>
                <h3
                  className="text-lg font-bold text-[#082E47] mb-2"
                  style={{ fontFamily: "Syne, sans-serif" }}
                >
                  {card.title}
                </h3>
                <p className="text-[#4A6070] text-sm leading-relaxed mb-4">{card.description}</p>
                <a
                  href={card.link}
                  className="text-[#1D9BEE] hover:text-[#1883CA] text-sm font-semibold transition-colors"
                  aria-label={`${card.linkLabel} — ${card.title}`}
                >
                  {card.linkLabel}
                </a>
              </div>
            </div>
          ))}
        </div>

        {/* CTA — contribute */}
        <div
          className="rounded-3xl p-8 md:p-12 text-center relative overflow-hidden"
          style={{ background: "linear-gradient(135deg, #082E47 0%, #0E4D77 50%, #146CA6 100%)" }}
        >
          {/* Decorative braille pattern */}
          <div className="absolute top-6 right-6 grid gap-1.5 opacity-20 pointer-events-none" style={{ gridTemplateColumns: "repeat(2, 8px)" }}>
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="w-2 h-2 rounded-full bg-[#1D9BEE]" />
            ))}
          </div>
          <div className="absolute bottom-6 left-6 grid gap-1.5 opacity-15 pointer-events-none" style={{ gridTemplateColumns: "repeat(2, 8px)" }}>
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="w-2 h-2 rounded-full bg-[#4EB1F1]" />
            ))}
          </div>

          <div className="relative z-10">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 mb-6 rounded-full border border-[#1D9BEE]/40 bg-[#1D9BEE]/10 text-[#82C8F5] text-xs font-semibold tracking-wide uppercase">
              Open Source
            </div>
            <h2
              className="text-2xl md:text-3xl font-extrabold text-white mb-4"
              style={{ fontFamily: "Syne, sans-serif" }}
            >
              Construído pela comunidade,{" "}
              <span className="text-[#4EB1F1]">para a comunidade</span>
            </h2>
            <p className="text-[#AFDCF9] text-lg mb-8 max-w-xl mx-auto leading-relaxed">
              O AssistiView SDK é open source e aceita contribuições. Reporte bugs,
              sugira melhorias ou envie pull requests no GitHub.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href="https://github.com/assistiview"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 px-7 py-3.5 bg-white hover:bg-[#ECF7FD] text-[#082E47] font-semibold rounded-xl transition-all duration-200 hover:shadow-lg"
                aria-label="Ver repositório do AssistiView no GitHub"
              >
                <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                  <path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/>
                </svg>
                Ver no GitHub
              </a>
              <a
                href="#install"
                onClick={(e) => {
                  e.preventDefault();
                  document.querySelector("#install")?.scrollIntoView({ behavior: "smooth" });
                }}
                className="inline-flex items-center justify-center gap-2 px-7 py-3.5 bg-[#1D9BEE] hover:bg-[#1883CA] text-white font-semibold rounded-xl transition-all duration-200 hover:shadow-lg hover:shadow-[#1D9BEE]/30"
                aria-label="Instalar o AssistiView SDK"
              >
                Instalar SDK
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
