/* ============================================================
   Hero — AssistiView SDK Landing Page
   Design: "Signal & Structure"
   - Fundo escuro (#082E47 → #041723) com imagem hero-bg
   - Clip-path diagonal na base
   - Pontos Braille animados como decoração
   - Texto branco/azul claro sobre fundo escuro
   - Mockup de smartphone flutuando à direita
   ============================================================ */

import { useEffect, useRef } from "react";

const HERO_BG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663441144974/Myyhi5NYLkCckQXr947Qbj/hero-bg-BLT95yb76B9qHLoxUVoz3q.webp";
const PHONE_MOCKUP = "https://d2xsxph8kpxj0f.cloudfront.net/310519663441144974/Myyhi5NYLkCckQXr947Qbj/phone-mockup-dstWZ6aEnRzN6iqsrKoeYn.webp";

// Braille dots pattern (6-dot cell: 2 cols × 3 rows)
function BrailleCell({ delay = 0, opacity = 0.3 }: { delay?: number; opacity?: number }) {
  return (
    <div
      className="grid gap-1"
      style={{ gridTemplateColumns: "repeat(2, 6px)", opacity }}
    >
      {Array.from({ length: 6 }).map((_, i) => (
        <div
          key={i}
          className="w-1.5 h-1.5 rounded-full bg-[#1D9BEE]"
          style={{
            animation: `pulse-dot ${1.5 + (i * 0.2)}s ease-in-out ${delay + i * 0.1}s infinite`,
          }}
        />
      ))}
    </div>
  );
}

function FloatingBrailleDots() {
  const positions = [
    { top: "12%", left: "5%", delay: 0, opacity: 0.25 },
    { top: "25%", left: "88%", delay: 0.5, opacity: 0.2 },
    { top: "60%", left: "3%", delay: 1, opacity: 0.15 },
    { top: "70%", left: "92%", delay: 0.3, opacity: 0.2 },
    { top: "40%", left: "50%", delay: 0.8, opacity: 0.1 },
  ];

  return (
    <>
      {positions.map((pos, i) => (
        <div
          key={i}
          className="absolute pointer-events-none"
          style={{ top: pos.top, left: pos.left }}
        >
          <BrailleCell delay={pos.delay} opacity={pos.opacity} />
        </div>
      ))}
    </>
  );
}

export default function Hero() {
  const heroRef = useRef<HTMLDivElement>(null);

  // Subtle parallax on scroll
  useEffect(() => {
    const handleScroll = () => {
      if (!heroRef.current) return;
      const scrollY = window.scrollY;
      heroRef.current.style.backgroundPositionY = `${scrollY * 0.3}px`;
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <section
      ref={heroRef}
      className="relative min-h-[100svh] flex items-center overflow-hidden"
      style={{
        background: `linear-gradient(135deg, #041723 0%, #082E47 50%, #0E4D77 100%)`,
        backgroundImage: `url(${HERO_BG})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
      }}
      aria-label="Seção principal — AssistiView SDK"
    >
      {/* Dark overlay for text readability */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#041723]/80 via-[#082E47]/70 to-[#0E4D77]/60" />

      {/* Decorative braille dots */}
      <FloatingBrailleDots />

      {/* Diagonal bottom clip */}
      <div
        className="absolute bottom-0 left-0 right-0 h-24 bg-white"
        style={{ clipPath: "polygon(0 100%, 100% 0, 100% 100%)" }}
      />

      <div className="container relative z-10 pt-24 pb-32">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left: text content */}
          <div className="animate-fade-in-up">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 px-3 py-1.5 mb-6 rounded-full border border-[#1D9BEE]/40 bg-[#1D9BEE]/10 text-[#82C8F5] text-xs font-medium tracking-wide uppercase">
              <span className="w-1.5 h-1.5 rounded-full bg-[#1D9BEE] animate-pulse" />
              SDK Kotlin para Android
            </div>

            {/* Main heading */}
            <h1
              className="text-4xl md:text-5xl lg:text-6xl font-extrabold text-white leading-tight mb-6"
              style={{ fontFamily: "Syne, sans-serif" }}
            >
              Acessibilidade{" "}
              <span className="text-[#1D9BEE]">nativa</span>{" "}
              para qualquer{" "}
              <span className="text-[#4EB1F1]">interface Android</span>
            </h1>

            {/* Subtitle */}
            <p className="text-[#AFDCF9] text-lg md:text-xl leading-relaxed mb-8 max-w-lg">
              O <strong className="text-white">AssistiView SDK</strong> permite que desenvolvedores
              Kotlin integrem suporte completo ao TalkBack e às APIs de acessibilidade do Android
              em poucas linhas de código — tornando seus apps acessíveis a pessoas cegas de forma
              dinâmica e eficiente.
            </p>

            {/* Code snippet teaser */}
            <div className="mb-8 rounded-xl border border-[#1D9BEE]/30 bg-[#041723]/80 backdrop-blur-sm p-4 font-mono text-sm">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-3 h-3 rounded-full bg-red-500/70" />
                <div className="w-3 h-3 rounded-full bg-yellow-500/70" />
                <div className="w-3 h-3 rounded-full bg-green-500/70" />
                <span className="ml-2 text-[#4EB1F1]/60 text-xs">build.gradle.kts</span>
              </div>
              <pre className="text-[#82C8F5] leading-relaxed overflow-x-auto">
                <code>{`implementation("io.assistiview:sdk:1.0.0")`}</code>
              </pre>
            </div>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row gap-4">
              <a
                href="#install"
                onClick={(e) => {
                  e.preventDefault();
                  document.querySelector("#install")?.scrollIntoView({ behavior: "smooth" });
                }}
                className="inline-flex items-center justify-center gap-2 px-7 py-3.5 bg-[#1D9BEE] hover:bg-[#1883CA] text-white font-semibold rounded-xl transition-all duration-200 hover:shadow-xl hover:shadow-[#1D9BEE]/30 hover:-translate-y-0.5"
                aria-label="Ver guia de instalação do AssistiView SDK"
              >
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                  <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                  <polyline points="7 10 12 15 17 10" />
                  <line x1="12" y1="15" x2="12" y2="3" />
                </svg>
                Instalar SDK
              </a>
              <a
                href="#docs"
                onClick={(e) => {
                  e.preventDefault();
                  document.querySelector("#docs")?.scrollIntoView({ behavior: "smooth" });
                }}
                className="inline-flex items-center justify-center gap-2 px-7 py-3.5 border border-[#1D9BEE]/50 hover:border-[#1D9BEE] text-[#AFDCF9] hover:text-white font-semibold rounded-xl transition-all duration-200 hover:bg-[#1D9BEE]/10"
                aria-label="Ver documentação do AssistiView SDK"
              >
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                  <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
                  <polyline points="14 2 14 8 20 8" />
                  <line x1="16" y1="13" x2="8" y2="13" />
                  <line x1="16" y1="17" x2="8" y2="17" />
                  <polyline points="10 9 9 9 8 9" />
                </svg>
                Ver documentação
              </a>
            </div>

            {/* Trust badges */}
            <div className="mt-10 flex flex-wrap items-center gap-6 text-[#82C8F5]/70 text-xs font-medium">
              <div className="flex items-center gap-1.5">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
                Open Source
              </div>
              <div className="flex items-center gap-1.5">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                WCAG 2.1 AA
              </div>
              <div className="flex items-center gap-1.5">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>
                Android API 21+
              </div>
              <div className="flex items-center gap-1.5">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>
                Kotlin First
              </div>
            </div>
          </div>

          {/* Right: phone mockup */}
          <div className="hidden lg:flex items-center justify-center">
            <div
              className="relative animate-float"
              style={{ filter: "drop-shadow(0 30px 60px rgba(29,155,238,0.35))" }}
            >
              <img
                src={PHONE_MOCKUP}
                alt="Interface de acessibilidade do AssistiView SDK em um smartphone Android"
                className="w-72 xl:w-80 object-contain"
                loading="eager"
              />
              {/* Glow ring */}
              <div className="absolute inset-0 rounded-3xl animate-glow pointer-events-none" />
            </div>
          </div>
        </div>

        {/* Stats bar */}
        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-6 border-t border-[#1D9BEE]/20 pt-10">
          {[
            { value: "< 5 min", label: "para integrar" },
            { value: "100%", label: "TalkBack nativo" },
            { value: "API 21+", label: "compatibilidade" },
            { value: "Open Source", label: "licença MIT" },
          ].map((stat) => (
            <div key={stat.label} className="text-center">
              <div
                className="text-2xl md:text-3xl font-extrabold text-[#1D9BEE] mb-1"
                style={{ fontFamily: "Syne, sans-serif" }}
              >
                {stat.value}
              </div>
              <div className="text-[#82C8F5]/70 text-sm">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
