/* ============================================================
   InstallSection — AssistiView SDK Landing Page
   Design: "Signal & Structure"
   - Fundo escuro (av-blue-900) espelhando o hero
   - Bloco de código com syntax highlighting manual
   - Tabs: Gradle / Maven / Source
   ============================================================ */

import { useState } from "react";

const CODE_VISUAL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663441144974/Myyhi5NYLkCckQXr947Qbj/code-visual-o3SM9yCuna5jwJ9E4Erwes.webp";

type TabKey = "gradle" | "maven" | "source";

const tabs: { key: TabKey; label: string }[] = [
  { key: "gradle", label: "Gradle KTS" },
  { key: "maven", label: "Maven" },
  { key: "source", label: "Código fonte" },
];

const codeSnippets: Record<TabKey, { lang: string; code: string }> = {
  gradle: {
    lang: "kotlin",
    code: `// build.gradle.kts (app)
dependencies {
    implementation("io.assistiview:sdk:1.0.0")
    
    // Opcional: extensões para Jetpack Compose
    implementation("io.assistiview:sdk-compose:1.0.0")
}`,
  },
  maven: {
    lang: "xml",
    code: `<!-- pom.xml -->
<dependency>
    <groupId>io.assistiview</groupId>
    <artifactId>sdk</artifactId>
    <version>1.0.0</version>
</dependency>

<!-- Opcional: extensões para Compose -->
<dependency>
    <groupId>io.assistiview</groupId>
    <artifactId>sdk-compose</artifactId>
    <version>1.0.0</version>
</dependency>`,
  },
  source: {
    lang: "bash",
    code: `# Clone o repositório
git clone https://github.com/assistiview/sdk-android.git

# Entre no diretório
cd sdk-android

# Compile e publique localmente
./gradlew publishToMavenLocal

# Adicione ao seu projeto
# settings.gradle.kts
mavenLocal()`,
  },
};

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // fallback silently
    }
  };

  return (
    <button
      onClick={handleCopy}
      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#1D9BEE]/20 hover:bg-[#1D9BEE]/40 text-[#82C8F5] hover:text-white text-xs font-medium transition-all duration-200"
      aria-label={copied ? "Código copiado!" : "Copiar código"}
    >
      {copied ? (
        <>
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" aria-hidden="true"><polyline points="20 6 9 17 4 12"/></svg>
          Copiado!
        </>
      ) : (
        <>
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
            <rect x="9" y="9" width="13" height="13" rx="2" ry="2"/>
            <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
          </svg>
          Copiar
        </>
      )}
    </button>
  );
}

export default function InstallSection() {
  const [activeTab, setActiveTab] = useState<TabKey>("gradle");
  const snippet = codeSnippets[activeTab];

  return (
    <section
      id="install"
      className="py-24 relative overflow-hidden"
      style={{ background: "linear-gradient(135deg, #041723 0%, #082E47 60%, #0E4D77 100%)" }}
      aria-labelledby="install-heading"
    >
      {/* Background code visual */}
      <div className="absolute right-0 top-0 bottom-0 w-1/2 opacity-10 pointer-events-none hidden lg:block">
        <img src={CODE_VISUAL} alt="" className="w-full h-full object-cover" aria-hidden="true" />
      </div>

      {/* Decorative braille dots */}
      <div className="absolute top-12 left-8 grid gap-1.5 opacity-20 pointer-events-none" style={{ gridTemplateColumns: "repeat(2, 8px)" }}>
        {Array.from({ length: 6 }).map((_, i) => (
          <div key={i} className="w-2 h-2 rounded-full bg-[#1D9BEE]" />
        ))}
      </div>

      <div className="container relative z-10">
        <div className="max-w-3xl">
          {/* Header */}
          <div className="inline-flex items-center gap-2 px-3 py-1.5 mb-6 rounded-full border border-[#1D9BEE]/40 bg-[#1D9BEE]/10 text-[#82C8F5] text-xs font-semibold tracking-wide uppercase">
            Instalação
          </div>
          <h2
            id="install-heading"
            className="text-3xl md:text-4xl font-extrabold text-white mb-4"
            style={{ fontFamily: "Syne, sans-serif" }}
          >
            Pronto para usar em{" "}
            <span className="text-[#1D9BEE]">minutos</span>
          </h2>
          <p className="text-[#AFDCF9] text-lg mb-10 leading-relaxed">
            Disponível via Maven Central. Compatível com Android API 21+ e Kotlin 1.8+.
            Sem configuração de repositório adicional necessária.
          </p>

          {/* Code block with tabs */}
          <div className="rounded-2xl border border-[#1D9BEE]/30 overflow-hidden shadow-2xl shadow-[#1D9BEE]/10">
            {/* Tab bar */}
            <div className="flex items-center gap-0 bg-[#041723] border-b border-[#1D9BEE]/20 px-4">
              {/* Window dots */}
              <div className="flex items-center gap-1.5 mr-4 py-3">
                <div className="w-3 h-3 rounded-full bg-red-500/60" />
                <div className="w-3 h-3 rounded-full bg-yellow-500/60" />
                <div className="w-3 h-3 rounded-full bg-green-500/60" />
              </div>
              {/* Tabs */}
              <div className="flex">
                {tabs.map((tab) => (
                  <button
                    key={tab.key}
                    onClick={() => setActiveTab(tab.key)}
                    className={`px-4 py-3 text-xs font-medium transition-all duration-200 border-b-2 ${
                      activeTab === tab.key
                        ? "text-[#1D9BEE] border-[#1D9BEE]"
                        : "text-[#4EB1F1]/60 border-transparent hover:text-[#4EB1F1]"
                    }`}
                    aria-selected={activeTab === tab.key}
                    role="tab"
                  >
                    {tab.label}
                  </button>
                ))}
              </div>
              {/* Copy button */}
              <div className="ml-auto py-2">
                <CopyButton text={snippet.code} />
              </div>
            </div>

            {/* Code content */}
            <div className="bg-[#020D14] p-6 overflow-x-auto">
              <pre className="text-sm leading-relaxed font-mono">
                <code className="text-[#82C8F5]">{snippet.code}</code>
              </pre>
            </div>
          </div>

          {/* Requirements */}
          <div className="mt-8 grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { label: "Kotlin", value: "1.8+" },
              { label: "Android API", value: "21+" },
              { label: "AGP", value: "8.0+" },
              { label: "Tamanho", value: "< 50KB" },
            ].map((req) => (
              <div
                key={req.label}
                className="rounded-xl border border-[#1D9BEE]/20 bg-[#1D9BEE]/5 p-4 text-center"
              >
                <div className="text-[#1D9BEE] font-bold text-lg mb-1" style={{ fontFamily: "Syne, sans-serif" }}>
                  {req.value}
                </div>
                <div className="text-[#82C8F5]/70 text-xs">{req.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
