/* ============================================================
   Navbar — AssistiView SDK Landing Page
   Design: "Signal & Structure" — sticky, blur backdrop, logo + nav links
   ============================================================ */

import { useState, useEffect } from "react";

const LOGO_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663441144974/Myyhi5NYLkCckQXr947Qbj/logo-assistiview_217f65cf.png";

const navLinks = [
  { label: "Recursos", href: "#features" },
  { label: "Como funciona", href: "#how-it-works" },
  { label: "Instalação", href: "#install" },
  { label: "Documentação", href: "#docs" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleNavClick = (href: string) => {
    setMenuOpen(false);
    const el = document.querySelector(href);
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-[#041723]/90 backdrop-blur-md border-b border-[#1D9BEE]/20 shadow-lg shadow-[#1D9BEE]/5"
          : "bg-transparent"
      }`}
    >
      <div className="container">
        <nav className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <a
            href="#"
            className="flex items-center gap-2"
            aria-label="AssistiView SDK — Página inicial"
          >
            <img
              src={LOGO_URL}
              alt="AssistiView SDK"
              className="h-8 md:h-10 w-auto"
            />
          </a>

          {/* Desktop nav links */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <button
                key={link.href}
                onClick={() => handleNavClick(link.href)}
                className="text-[#AFDCF9] hover:text-white text-sm font-medium transition-colors duration-200 relative group"
              >
                {link.label}
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-[#1D9BEE] transition-all duration-300 group-hover:w-full" />
              </button>
            ))}
          </div>

          {/* CTA button */}
          <div className="hidden md:flex items-center gap-4">
            <a
              href="#install"
              onClick={(e) => { e.preventDefault(); handleNavClick("#install"); }}
              className="px-5 py-2 bg-[#1D9BEE] hover:bg-[#1883CA] text-white text-sm font-semibold rounded-lg transition-all duration-200 hover:shadow-lg hover:shadow-[#1D9BEE]/30"
            >
              Começar agora
            </a>
          </div>

          {/* Mobile hamburger */}
          <button
            className="md:hidden flex flex-col gap-1.5 p-2"
            onClick={() => setMenuOpen(!menuOpen)}
            aria-label={menuOpen ? "Fechar menu" : "Abrir menu"}
          >
            <span className={`block w-6 h-0.5 bg-[#AFDCF9] transition-all duration-300 ${menuOpen ? "rotate-45 translate-y-2" : ""}`} />
            <span className={`block w-6 h-0.5 bg-[#AFDCF9] transition-all duration-300 ${menuOpen ? "opacity-0" : ""}`} />
            <span className={`block w-6 h-0.5 bg-[#AFDCF9] transition-all duration-300 ${menuOpen ? "-rotate-45 -translate-y-2" : ""}`} />
          </button>
        </nav>

        {/* Mobile menu */}
        {menuOpen && (
          <div className="md:hidden bg-[#041723]/95 backdrop-blur-md border-t border-[#1D9BEE]/20 py-4 flex flex-col gap-4 px-4">
            {navLinks.map((link) => (
              <button
                key={link.href}
                onClick={() => handleNavClick(link.href)}
                className="text-[#AFDCF9] hover:text-white text-base font-medium text-left transition-colors"
              >
                {link.label}
              </button>
            ))}
            <a
              href="#install"
              onClick={(e) => { e.preventDefault(); handleNavClick("#install"); }}
              className="mt-2 px-5 py-2.5 bg-[#1D9BEE] text-white text-sm font-semibold rounded-lg text-center"
            >
              Começar agora
            </a>
          </div>
        )}
      </div>
    </header>
  );
}
