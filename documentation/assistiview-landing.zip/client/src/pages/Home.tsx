/* ============================================================
   Home — AssistiView SDK Landing Page
   Design: "Signal & Structure" — Editorial Técnico com Profundidade
   Fontes: Syne (display) + DM Sans (body) + JetBrains Mono (code)
   Paleta: av-blue-500 (#1D9BEE) como cor primária
   ============================================================ */

import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import Features from "@/components/Features";
import HowItWorks from "@/components/HowItWorks";
import InstallSection from "@/components/InstallSection";
import DocsSection from "@/components/DocsSection";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col">
      {/* Skip to main content — accessibility */}
      <a
        href="#features"
        className="sr-only focus:not-sr-only focus:fixed focus:top-4 focus:left-4 focus:z-[100] focus:px-4 focus:py-2 focus:bg-[#1D9BEE] focus:text-white focus:rounded-lg focus:font-semibold"
      >
        Pular para o conteúdo principal
      </a>

      <Navbar />

      <main id="main-content">
        <Hero />
        <Features />
        <HowItWorks />
        <InstallSection />
        <DocsSection />
      </main>

      <Footer />
    </div>
  );
}
